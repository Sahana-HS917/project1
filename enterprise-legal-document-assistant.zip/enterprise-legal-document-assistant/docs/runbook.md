# Step-by-Step Execution Guide

## Git Bash

```bash
cd /c/Users/ADMIN/Documents/Codex/2026-05-12/build-a-production-ready-end-to/enterprise-legal-document-assistant
cp .env.example .env
docker compose up --build
```

Open:

- Streamlit: http://localhost:8501
- API docs: http://localhost:8000/docs

## VS Code

1. Open the `enterprise-legal-document-assistant` folder.
2. Open a terminal.
3. Run:

```bash
cp .env.example .env
docker compose up --build
```

## Local Python

```bash
python -m venv .venv
source .venv/Scripts/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Then start the UI:

```bash
streamlit run app/frontend/streamlit_app.py
```

## Offline Ollama

```bash
docker compose --profile ollama up --build
docker exec -it enterprise-legal-document-assistant-ollama-1 ollama pull llama3.1:8b
```

For smaller machines, set `OLLAMA_MODEL=tinyllama` or `OLLAMA_MODEL=phi3:mini`.

## Typical Workflow

1. Upload one or more PDFs, DOCX files, or TXT files in the sidebar.
2. Wait for document status to show `indexed`.
3. Ask a question in the chat box.
4. Review the answer citations.
5. Expand source chunks to inspect the evidence.
6. Use `/reindex` after manual data migrations.

