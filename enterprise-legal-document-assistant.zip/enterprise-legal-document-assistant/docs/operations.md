# Operations

## Index Strategy

- Small deployment: one FAISS/BM25 index.
- Medium firm: shard by matter or client.
- Large corpus: shard by matter and use metadata routing before retrieval.

## Monitoring

Track:

- Query latency
- Retrieval precision and recall
- Refusal rate
- Citation validation failures
- OCR failure rate
- Average chunks per document
- Top reranker latency

## Quality Gates

Before production:

- Build a labeled retrieval eval set.
- Require precision@5 above 0.90 on internal benchmark questions.
- Review refusal behavior with attorneys.
- Red-team unsupported questions.

