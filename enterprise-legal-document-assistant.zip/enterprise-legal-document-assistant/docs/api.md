# API Documentation

FastAPI serves interactive docs at `/docs`.

## Endpoints

- `POST /upload`: upload one PDF, DOCX, or TXT file.
- `POST /query`: ask a citation-aware question.
- `GET /documents`: list indexed documents.
- `DELETE /documents/{id}`: delete document metadata and chunks.
- `POST /reindex`: rebuild FAISS and BM25 indexes.
- `GET /health`: health probe.
- `POST /documents/{document_id}/summary`: document summarization with citations.
- `POST /analysis/clause`: legal clause extraction.
- `POST /analysis/risk`: contract risk analysis.

## Query Example

```bash
curl -X POST http://localhost:8000/query \
  -H "Content-Type: application/json" \
  -H "X-API-Key: dev-local-key" \
  -d '{"question":"What does the agreement say about assignment?","session_id":"demo"}'
```
