# Architecture

## Pipeline

```mermaid
sequenceDiagram
    participant U as User
    participant UI as Streamlit
    participant API as FastAPI
    participant I as Ingestion
    participant V as FAISS/BM25
    participant R as Reranker
    participant L as LLM
    participant C as Citation Validator

    U->>UI: Upload legal documents
    UI->>API: POST /upload
    API->>I: Parse, OCR, chunk, embed
    I->>V: Persist dense and sparse indexes
    U->>UI: Ask question
    UI->>API: POST /query
    API->>V: Hybrid retrieval
    V->>R: Candidate chunks
    R->>L: Compressed context
    L->>C: Draft answer
    C->>UI: Answer with citations or refusal
```

## Module Responsibilities

- `app/ingestion`: extracts text from PDF, DOCX, TXT, and scanned PDFs.
- `app/vectorstore`: generates cached embeddings and maintains FAISS plus BM25 indexes.
- `app/rag`: query rewriting, retrieval, reranking, generation, memory, citation validation, and evaluation.
- `app/api`: upload, query, documents, delete, reindex, and health endpoints.
- `app/frontend`: Streamlit interface for attorneys and knowledge teams.
- `app/storage`: SQLite metadata and local/S3 upload storage.

## Scalability

For 500,000 pages, use matter-level sharding. Create one FAISS/BM25 index per client, matter, or practice group. Route queries by document filters, and keep global search only for curated research libraries. Ingestion should be moved to a worker queue for high-volume batch loads.

## Bottlenecks

- OCR is CPU-heavy; run it asynchronously and cache page text.
- Cross-encoder reranking improves precision but adds latency.
- Large context windows cost money online and memory offline.
- FAISS `IndexFlatIP` is exact and simple; for millions of chunks, switch to IVF/HNSW.

