# Security

- API key protection is enabled through `X-API-Key`.
- Uploads are limited by size and extension.
- Logs should never include document text or client names beyond controlled metadata.
- Store secrets in AWS Systems Manager Parameter Store or Secrets Manager.
- Use TLS in production.
- Use private S3 buckets with IAM instance roles.
- Add SSO/OIDC before deployment to a real law firm.
- Run virus scanning and DLP on uploaded files in regulated environments.

