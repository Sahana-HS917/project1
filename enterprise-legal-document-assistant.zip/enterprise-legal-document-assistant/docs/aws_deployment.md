# AWS Free-Tier Deployment

## EC2

1. Launch an Ubuntu `t3.micro` or `t2.micro` instance.
2. Open ports `22`, `80`, and optionally `443`.
3. Install Docker and Docker Compose plugin.
4. Clone or copy this repository.
5. Create `.env` from `.env.example`.
6. Run `docker compose up -d --build`.

## Nginx

Use Nginx as a reverse proxy from port 80 to Streamlit and FastAPI.

```nginx
server {
    listen 80;
    server_name _;

    location /api/ {
        proxy_pass http://127.0.0.1:8000/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    location / {
        proxy_pass http://127.0.0.1:8501/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
    }
}
```

## S3

- Create a private S3 bucket.
- Set `STORAGE_BACKEND=s3`.
- Set `S3_BUCKET` and `AWS_REGION`.
- Attach an EC2 instance role with `s3:GetObject`, `s3:PutObject`, and `s3:DeleteObject` scoped to that bucket.

## Lambda Async Ingestion

For larger firms, upload files to S3 and trigger Lambda or SQS workers that call the ingestion API. Keep the web API responsive and isolate OCR from user traffic.

## Cost Optimization

- Use MiniLM embeddings on CPU for free-tier compatibility.
- Use Ollama TinyLlama/Phi-3 on larger local machines, not on `t3.micro`.
- Persist `data/` on EBS and back it up with snapshots.
- Use S3 lifecycle policies for archived source documents.

