import argparse
import asyncio
from pathlib import Path

from fastapi import UploadFile

from app.ingestion.service import IngestionService
from app.storage.database import Document, SessionLocal, init_db
from app.storage.object_store import save_upload


class LocalUpload:
    def __init__(self, path: Path):
        self.filename = path.name
        self.content_type = "application/octet-stream"
        self._content = path.read_bytes()

    async def read(self):
        return self._content


async def ingest_directory(path: str):
    init_db()
    db = SessionLocal()
    service = IngestionService()
    for file_path in Path(path).rglob("*"):
        if file_path.suffix.lower() not in {".pdf", ".docx", ".txt"}:
            continue
        storage_uri, digest = await save_upload(LocalUpload(file_path))
        existing = db.query(Document).filter(Document.sha256 == digest).first()
        if existing:
            print(f"skip duplicate: {file_path.name}")
            continue
        document = Document(
            filename=file_path.name,
            content_type="application/octet-stream",
            storage_uri=storage_uri,
            sha256=digest,
        )
        db.add(document)
        db.commit()
        db.refresh(document)
        count = service.ingest(db, document)
        print(f"indexed {file_path.name}: {count} chunks")
    db.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("path")
    asyncio.run(ingest_directory(parser.parse_args().path))

