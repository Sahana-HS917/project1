import argparse
import json

from app.rag.evaluation import precision_at_k, recall_at_k
from app.rag.retrieval import HybridRetriever
from app.storage.database import SessionLocal, init_db


def main(path: str):
    init_db()
    db = SessionLocal()
    retriever = HybridRetriever()
    rows = [json.loads(line) for line in open(path, encoding="utf-8") if line.strip()]
    precision, recall = [], []
    for row in rows:
        retrieved = retriever.retrieve(db, row["question"])
        ids = [chunk.chunk_id for chunk in retrieved]
        expected = set(row["expected_chunk_ids"])
        precision.append(precision_at_k(expected, ids, 5))
        recall.append(recall_at_k(expected, ids, 5))
    print({"precision_at_5": sum(precision) / max(len(precision), 1), "recall_at_5": sum(recall) / max(len(recall), 1)})


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("eval_jsonl")
    main(parser.parse_args().eval_jsonl)

