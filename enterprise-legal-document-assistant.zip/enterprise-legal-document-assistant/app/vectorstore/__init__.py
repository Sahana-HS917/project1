"""Vector store package."""

