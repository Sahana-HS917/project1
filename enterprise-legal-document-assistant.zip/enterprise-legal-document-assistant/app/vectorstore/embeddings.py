import hashlib
import sqlite3
from pathlib import Path

import numpy as np

from app.config.settings import get_settings


class EmbeddingService:
    def __init__(self):
        self.settings = get_settings()
        self._model = None
        Path(self.settings.embedding_cache_path).parent.mkdir(parents=True, exist_ok=True)
        self._init_cache()

    def _init_cache(self) -> None:
        with sqlite3.connect(self.settings.embedding_cache_path) as conn:
            conn.execute(
                "CREATE TABLE IF NOT EXISTS embeddings (cache_key TEXT PRIMARY KEY, dim INTEGER, vector BLOB)"
            )

    @property
    def model(self):
        if self._model is None:
            from sentence_transformers import SentenceTransformer

            self._model = SentenceTransformer(self.settings.embedding_model)
        return self._model

    def embed_texts(self, texts: list[str]) -> np.ndarray:
        vectors = []
        misses = []
        miss_indices = []
        for idx, text in enumerate(texts):
            cached = self._get(text)
            if cached is None:
                misses.append(text)
                miss_indices.append(idx)
                vectors.append(None)
            else:
                vectors.append(cached)
        if misses:
            encoded = self.model.encode(misses, normalize_embeddings=True, show_progress_bar=False)
            for text, vector, idx in zip(misses, encoded, miss_indices):
                vector = np.asarray(vector, dtype="float32")
                self._put(text, vector)
                vectors[idx] = vector
        return np.vstack(vectors).astype("float32")

    def _key(self, text: str) -> str:
        return hashlib.sha256((self.settings.embedding_model + "::" + text).encode("utf-8")).hexdigest()

    def _get(self, text: str) -> np.ndarray | None:
        with sqlite3.connect(self.settings.embedding_cache_path) as conn:
            row = conn.execute("SELECT dim, vector FROM embeddings WHERE cache_key=?", (self._key(text),)).fetchone()
        if not row:
            return None
        dim, blob = row
        return np.frombuffer(blob, dtype="float32").reshape(dim)

    def _put(self, text: str, vector: np.ndarray) -> None:
        with sqlite3.connect(self.settings.embedding_cache_path) as conn:
            conn.execute(
                "INSERT OR REPLACE INTO embeddings(cache_key, dim, vector) VALUES (?, ?, ?)",
                (self._key(text), int(vector.shape[0]), vector.astype("float32").tobytes()),
            )

