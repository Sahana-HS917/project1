import pickle
from pathlib import Path

import faiss
import numpy as np
from rank_bm25 import BM25Okapi
from sqlalchemy.orm import Session

from app.config.settings import get_settings
from app.storage.database import Chunk
from app.vectorstore.embeddings import EmbeddingService


def tokenize(text: str) -> list[str]:
    return [token.lower() for token in text.split() if token.strip()]


class VectorIndex:
    def __init__(self):
        self.settings = get_settings()
        self.embeddings = EmbeddingService()
        self.index = None
        self.chunk_ids: list[str] = []
        self.bm25 = None
        self.bm25_chunk_ids: list[str] = []

    def rebuild(self, db: Session) -> int:
        chunks = db.query(Chunk).order_by(Chunk.created_at.asc()).all()
        Path(self.settings.vector_index_path).parent.mkdir(parents=True, exist_ok=True)
        Path(self.settings.bm25_index_path).parent.mkdir(parents=True, exist_ok=True)
        if not chunks:
            self.index = None
            self.chunk_ids = []
            self.bm25 = None
            self.bm25_chunk_ids = []
            return 0
        texts = [chunk.text for chunk in chunks]
        vectors = self.embeddings.embed_texts(texts)
        self.index = faiss.IndexFlatIP(vectors.shape[1])
        self.index.add(vectors)
        self.chunk_ids = [chunk.id for chunk in chunks]
        faiss.write_index(self.index, self.settings.vector_index_path)
        Path(self.settings.vector_index_path + ".ids").write_text("\n".join(self.chunk_ids), encoding="utf-8")
        tokenized = [tokenize(text) for text in texts]
        self.bm25 = BM25Okapi(tokenized)
        self.bm25_chunk_ids = self.chunk_ids.copy()
        with open(self.settings.bm25_index_path, "wb") as fh:
            pickle.dump({"bm25": self.bm25, "chunk_ids": self.bm25_chunk_ids}, fh)
        return len(chunks)

    def load(self) -> None:
        if Path(self.settings.vector_index_path).exists():
            self.index = faiss.read_index(self.settings.vector_index_path)
            ids_path = Path(self.settings.vector_index_path + ".ids")
            self.chunk_ids = ids_path.read_text(encoding="utf-8").splitlines() if ids_path.exists() else []
        if Path(self.settings.bm25_index_path).exists():
            with open(self.settings.bm25_index_path, "rb") as fh:
                data = pickle.load(fh)
            self.bm25 = data["bm25"]
            self.bm25_chunk_ids = data["chunk_ids"]

    def dense_search(self, query: str, top_k: int) -> list[tuple[str, float]]:
        if self.index is None:
            self.load()
        if self.index is None or not self.chunk_ids:
            return []
        vector = self.embeddings.embed_texts([query])
        scores, indices = self.index.search(vector, top_k)
        return [
            (self.chunk_ids[int(idx)], float(score))
            for score, idx in zip(scores[0], indices[0])
            if idx >= 0 and int(idx) < len(self.chunk_ids)
        ]

    def sparse_search(self, query: str, top_k: int) -> list[tuple[str, float]]:
        if self.bm25 is None:
            self.load()
        if self.bm25 is None:
            return []
        scores = self.bm25.get_scores(tokenize(query))
        if len(scores) == 0:
            return []
        order = np.argsort(scores)[::-1][:top_k]
        return [(self.bm25_chunk_ids[int(idx)], float(scores[int(idx)])) for idx in order]


vector_index = VectorIndex()

