from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "Enterprise Legal Document Assistant"
    environment: str = "development"
    api_key: str = "dev-local-key"
    database_url: str = "sqlite:///./data/legal_rag.db"
    storage_backend: str = "local"
    local_storage_path: str = "./data/uploads"
    s3_bucket: str = ""
    aws_region: str = "us-east-1"
    vector_index_path: str = "./data/index/faiss.index"
    bm25_index_path: str = "./data/index/bm25.pkl"
    embedding_cache_path: str = "./data/cache/embeddings.sqlite"
    embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    reranker_model: str = "BAAI/bge-reranker-base"
    llm_provider: str = "ollama"
    ollama_base_url: str = "http://localhost:11434"
    ollama_model: str = "llama3.1:8b"
    openai_api_key: str = ""
    gemini_api_key: str = ""
    max_upload_mb: int = 100
    chunk_size_tokens: int = 1000
    chunk_overlap_tokens: int = 180
    top_k: int = 16
    rerank_top_k: int = 6
    rate_limit_per_minute: int = 60

    model_config = SettingsConfigDict(env_file=".env", case_sensitive=False)


@lru_cache
def get_settings() -> Settings:
    return Settings()

