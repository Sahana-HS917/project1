import logging


def configure_logging() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )


def pii_safe(value: str, max_len: int = 120) -> str:
    return value.replace("\n", " ")[:max_len]

