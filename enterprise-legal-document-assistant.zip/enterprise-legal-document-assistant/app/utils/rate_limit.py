import time
from collections import defaultdict, deque

from fastapi import HTTPException, Request

from app.config.settings import get_settings

WINDOW_SECONDS = 60
_requests: dict[str, deque[float]] = defaultdict(deque)


def check_rate_limit(request: Request) -> None:
    settings = get_settings()
    client = request.client.host if request.client else "unknown"
    now = time.time()
    bucket = _requests[client]
    while bucket and now - bucket[0] > WINDOW_SECONDS:
        bucket.popleft()
    if len(bucket) >= settings.rate_limit_per_minute:
        raise HTTPException(status_code=429, detail="Rate limit exceeded")
    bucket.append(now)

