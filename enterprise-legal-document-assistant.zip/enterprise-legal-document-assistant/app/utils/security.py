from fastapi import Header, HTTPException

from app.config.settings import get_settings


def require_api_key(x_api_key: str | None = Header(default=None)):
    settings = get_settings()
    if settings.environment == "development" and not x_api_key:
        return
    if x_api_key != settings.api_key:
        raise HTTPException(status_code=401, detail="Invalid API key")

