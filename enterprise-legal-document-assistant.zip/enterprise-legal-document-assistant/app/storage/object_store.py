import hashlib
from pathlib import Path
from uuid import uuid4

from fastapi import UploadFile

from app.config.settings import get_settings

ALLOWED_SUFFIXES = {".pdf", ".docx", ".txt"}


async def save_upload(file: UploadFile) -> tuple[str, str]:
    settings = get_settings()
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in ALLOWED_SUFFIXES:
        raise ValueError("Only PDF, DOCX, and TXT files are supported")
    content = await file.read()
    max_bytes = settings.max_upload_mb * 1024 * 1024
    if len(content) > max_bytes:
        raise ValueError(f"File exceeds {settings.max_upload_mb} MB limit")
    digest = hashlib.sha256(content).hexdigest()
    if settings.storage_backend == "s3":
        import boto3

        key = f"uploads/{uuid4()}-{Path(file.filename or 'document').name}"
        boto3.client("s3", region_name=settings.aws_region).put_object(
            Bucket=settings.s3_bucket,
            Key=key,
            Body=content,
            ContentType=file.content_type or "application/octet-stream",
        )
        return f"s3://{settings.s3_bucket}/{key}", digest
    root = Path(settings.local_storage_path)
    root.mkdir(parents=True, exist_ok=True)
    path = root / f"{uuid4()}-{Path(file.filename or 'document').name}"
    path.write_bytes(content)
    return str(path), digest

