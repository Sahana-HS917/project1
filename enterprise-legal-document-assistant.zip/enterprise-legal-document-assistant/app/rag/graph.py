from typing import TypedDict


class RAGState(TypedDict, total=False):
    question: str
    rewritten_query: str
    retrieved_chunks: list
    reranked_chunks: list
    answer: str
    citations: list


def build_langgraph_pipeline():
    """Return a LangGraph-compatible skeleton for teams that want graph orchestration.

    The production API uses `LegalRAGPipeline` directly for simple deployment. This
    function documents the same stages as a graph and can be expanded with durable
    checkpoints, human review, or agentic retrieval branches.
    """
    try:
        from langgraph.graph import END, StateGraph
    except Exception:
        return None

    graph = StateGraph(RAGState)
    graph.add_node("rewrite_query", lambda state: state)
    graph.add_node("hybrid_retrieve", lambda state: state)
    graph.add_node("rerank", lambda state: state)
    graph.add_node("compress_context", lambda state: state)
    graph.add_node("generate", lambda state: state)
    graph.add_node("validate_citations", lambda state: state)
    graph.set_entry_point("rewrite_query")
    graph.add_edge("rewrite_query", "hybrid_retrieve")
    graph.add_edge("hybrid_retrieve", "rerank")
    graph.add_edge("rerank", "compress_context")
    graph.add_edge("compress_context", "generate")
    graph.add_edge("generate", "validate_citations")
    graph.add_edge("validate_citations", END)
    return graph.compile()
