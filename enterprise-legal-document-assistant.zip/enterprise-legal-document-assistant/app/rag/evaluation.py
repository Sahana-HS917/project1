import time
from dataclasses import dataclass


@dataclass
class RetrievalExample:
    question: str
    expected_chunk_ids: set[str]
    retrieved_chunk_ids: list[str]
    latency_ms: float


def precision_at_k(expected: set[str], retrieved: list[str], k: int) -> float:
    if k <= 0:
        return 0.0
    top = retrieved[:k]
    return len(expected.intersection(top)) / max(len(top), 1)


def recall_at_k(expected: set[str], retrieved: list[str], k: int) -> float:
    if not expected:
        return 0.0
    return len(expected.intersection(retrieved[:k])) / len(expected)


def faithfulness(answer: str, citations: list[dict]) -> float:
    if "do not contain enough information" in answer:
        return 1.0
    return 1.0 if citations else 0.0


def context_relevance(question: str, chunks: list[str]) -> float:
    q_terms = {term.lower() for term in question.split() if len(term) > 3}
    if not q_terms or not chunks:
        return 0.0
    context_terms = set(" ".join(chunks).lower().split())
    return len(q_terms.intersection(context_terms)) / len(q_terms)


def hallucination_detected(answer: str, citations: list[dict]) -> bool:
    risky = ["generally", "typically", "as a matter of law", "outside the documents"]
    return (not citations and "do not contain enough information" not in answer) or any(term in answer.lower() for term in risky)

