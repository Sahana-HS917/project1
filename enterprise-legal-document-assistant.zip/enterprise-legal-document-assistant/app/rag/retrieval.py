from sqlalchemy.orm import Session

from app.config.settings import get_settings
from app.models.schemas import RetrievedChunk
from app.storage.database import Chunk
from app.vectorstore.index import vector_index


class HybridRetriever:
    def retrieve(self, db: Session, query: str, document_ids: list[str] | None = None, filters: dict | None = None) -> list[RetrievedChunk]:
        settings = get_settings()
        dense = vector_index.dense_search(query, settings.top_k)
        sparse = vector_index.sparse_search(query, settings.top_k)
        fused: dict[str, float] = {}
        for rank, (chunk_id, score) in enumerate(dense, start=1):
            fused[chunk_id] = fused.get(chunk_id, 0) + 0.65 * (1 / (rank + 60)) + 0.01 * score
        for rank, (chunk_id, score) in enumerate(sparse, start=1):
            fused[chunk_id] = fused.get(chunk_id, 0) + 0.35 * (1 / (rank + 60)) + 0.001 * score
        ordered = sorted(fused.items(), key=lambda item: item[1], reverse=True)
        if not ordered:
            return []
        query_obj = db.query(Chunk).filter(Chunk.id.in_([chunk_id for chunk_id, _ in ordered]))
        if document_ids:
            query_obj = query_obj.filter(Chunk.document_id.in_(document_ids))
        chunks = {chunk.id: chunk for chunk in query_obj.all()}
        results = []
        for chunk_id, score in ordered:
            chunk = chunks.get(chunk_id)
            if not chunk:
                continue
            if filters and filters.get("page_number") and chunk.page_number != int(filters["page_number"]):
                continue
            results.append(
                RetrievedChunk(
                    chunk_id=chunk.id,
                    document_id=chunk.document_id,
                    document_name=chunk.document_name,
                    page_number=chunk.page_number,
                    section_title=chunk.section_title,
                    text=chunk.text,
                    score=round(float(score), 6),
                )
            )
        return results[: settings.top_k]

