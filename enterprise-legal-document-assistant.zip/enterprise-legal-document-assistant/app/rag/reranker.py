from app.config.settings import get_settings
from app.models.schemas import RetrievedChunk


class Reranker:
    def __init__(self):
        self.settings = get_settings()
        self._model = None

    @property
    def model(self):
        if self._model is None:
            from sentence_transformers import CrossEncoder

            self._model = CrossEncoder(self.settings.reranker_model)
        return self._model

    def rerank(self, query: str, chunks: list[RetrievedChunk]) -> list[RetrievedChunk]:
        if not chunks:
            return []
        try:
            pairs = [(query, chunk.text[:4000]) for chunk in chunks]
            scores = self.model.predict(pairs)
            for chunk, score in zip(chunks, scores):
                chunk.score = float(score)
            return sorted(chunks, key=lambda item: item.score, reverse=True)[: self.settings.rerank_top_k]
        except Exception:
            return sorted(chunks, key=lambda item: item.score, reverse=True)[: self.settings.rerank_top_k]

