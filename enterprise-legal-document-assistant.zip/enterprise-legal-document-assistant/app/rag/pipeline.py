import re
import time

from sqlalchemy.orm import Session

from app.config.prompts import CONVERSATIONAL_CONTEXT_PROMPT, REFUSAL, STRICT_LEGAL_QA_SYSTEM_PROMPT
from app.ingestion.chunker import chunk_to_context
from app.models.schemas import Citation, QueryRequest, QueryResponse
from app.rag.llms import LLMClient
from app.rag.memory import ConversationMemory
from app.rag.reranker import Reranker
from app.rag.retrieval import HybridRetriever


class LegalRAGPipeline:
    def __init__(self):
        self.retriever = HybridRetriever()
        self.reranker = Reranker()
        self.memory = ConversationMemory()

    def rewrite_query(self, db: Session, request: QueryRequest) -> str:
        history = self.memory.recent(db, request.session_id, limit=4)
        if not history:
            return request.question
        prior = " ".join(message.content for message in history[-4:])
        return f"{request.question}\nConversation context for pronoun resolution only: {prior[-1200:]}"

    def build_prompt(self, question: str, context: str) -> str:
        return (
            f"{STRICT_LEGAL_QA_SYSTEM_PROMPT}\n\n"
            f"{CONVERSATIONAL_CONTEXT_PROMPT}\n\n"
            f"Retrieved context:\n{context}\n\n"
            f"Question: {question}\n\n"
            "Answer with concise legal research style, using citations after every factual sentence."
        )

    async def answer(self, db: Session, request: QueryRequest) -> QueryResponse:
        start = time.perf_counter()
        rewritten = self.rewrite_query(db, request)
        retrieved = self.retriever.retrieve(db, rewritten, request.document_ids, request.filters)
        reranked = self.reranker.rerank(rewritten, retrieved)
        context = "\n\n".join(chunk_to_context(chunk.model_dump()) for chunk in reranked)
        if not reranked:
            answer = REFUSAL
        else:
            prompt = self.build_prompt(request.question, context)
            answer = await LLMClient(request.provider).generate(prompt, context)
        answer, citations = self.validate_answer(answer, reranked)
        self.memory.add(db, request.session_id, "user", request.question)
        self.memory.add(db, request.session_id, "assistant", answer)
        latency_ms = (time.perf_counter() - start) * 1000
        return QueryResponse(
            answer=answer,
            citations=citations,
            retrieved_chunks=reranked,
            latency_ms=round(latency_ms, 2),
            session_id=request.session_id,
        )

    async def stream_answer(self, db: Session, request: QueryRequest):
        response = await self.answer(db, request)
        for token in response.answer.split():
            yield token + " "

    def validate_answer(self, answer: str, chunks) -> tuple[str, list[Citation]]:
        if not answer or answer.strip() == REFUSAL:
            return REFUSAL, []
        valid_refs = {(chunk.document_name, chunk.page_number, chunk.chunk_id): chunk for chunk in chunks}
        citations: list[Citation] = []
        for chunk in chunks:
            marker = f"[{chunk.document_name} | Page {chunk.page_number} | Chunk {chunk.chunk_id}]"
            if marker in answer:
                citations.append(
                    Citation(
                        document_id=chunk.document_id,
                        document_name=chunk.document_name,
                        page_number=chunk.page_number,
                        chunk_id=chunk.chunk_id,
                        section_title=chunk.section_title,
                    )
                )
        if not citations:
            # Attach citations when the provider gives a supported answer without formatting.
            first = chunks[0] if chunks else None
            if not first:
                return REFUSAL, []
            answer = answer.rstrip() + f" [{first.document_name} | Page {first.page_number} | Chunk {first.chunk_id}]"
            citations.append(
                Citation(
                    document_id=first.document_id,
                    document_name=first.document_name,
                    page_number=first.page_number,
                    chunk_id=first.chunk_id,
                    section_title=first.section_title,
                )
            )
        unsupported_patterns = ["as an ai", "generally", "in most cases", "outside the documents"]
        if any(pattern in answer.lower() for pattern in unsupported_patterns):
            return REFUSAL, []
        return answer, citations

