from sqlalchemy.orm import Session

from app.storage.database import ChatMessage


class ConversationMemory:
    def add(self, db: Session, session_id: str, role: str, content: str) -> None:
        db.add(ChatMessage(session_id=session_id, role=role, content=content))
        db.commit()

    def recent(self, db: Session, session_id: str, limit: int = 8) -> list[ChatMessage]:
        rows = (
            db.query(ChatMessage)
            .filter(ChatMessage.session_id == session_id)
            .order_by(ChatMessage.created_at.desc())
            .limit(limit)
            .all()
        )
        return list(reversed(rows))

