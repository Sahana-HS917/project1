import json

import httpx

from app.config.prompts import REFUSAL
from app.config.settings import get_settings


class LLMClient:
    def __init__(self, provider: str | None = None):
        self.settings = get_settings()
        self.provider = provider or self.settings.llm_provider

    async def generate(self, prompt: str, context: str) -> str:
        if self.provider == "ollama":
            return await self._ollama(prompt)
        if self.provider == "openai":
            return await self._openai(prompt)
        if self.provider == "gemini":
            return await self._gemini(prompt)
        return self._extractive(context)

    async def stream(self, prompt: str, context: str):
        text = await self.generate(prompt, context)
        for token in text.split():
            yield token + " "

    async def _ollama(self, prompt: str) -> str:
        try:
            async with httpx.AsyncClient(timeout=60) as client:
                response = await client.post(
                    f"{self.settings.ollama_base_url}/api/generate",
                    json={"model": self.settings.ollama_model, "prompt": prompt, "stream": False},
                )
            response.raise_for_status()
            return response.json().get("response", "").strip() or REFUSAL
        except Exception:
            return REFUSAL

    async def _openai(self, prompt: str) -> str:
        try:
            async with httpx.AsyncClient(timeout=60) as client:
                response = await client.post(
                    "https://api.openai.com/v1/chat/completions",
                    headers={"Authorization": f"Bearer {self.settings.openai_api_key}"},
                    json={
                        "model": "gpt-4o-mini",
                        "messages": [{"role": "user", "content": prompt}],
                        "temperature": 0,
                    },
                )
            response.raise_for_status()
            return response.json()["choices"][0]["message"]["content"].strip()
        except Exception:
            return REFUSAL

    async def _gemini(self, prompt: str) -> str:
        try:
            url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent"
            async with httpx.AsyncClient(timeout=60) as client:
                response = await client.post(
                    url,
                    params={"key": self.settings.gemini_api_key},
                    json={"contents": [{"parts": [{"text": prompt}]}], "generationConfig": {"temperature": 0}},
                )
            response.raise_for_status()
            data = response.json()
            return data["candidates"][0]["content"]["parts"][0]["text"].strip()
        except Exception:
            return REFUSAL

    def _extractive(self, context: str) -> str:
        lines = [line.strip() for line in context.splitlines() if line.strip()]
        cited = [line for line in lines if line.startswith("[")]
        if not cited:
            return REFUSAL
        snippet = " ".join(lines[:8])
        return snippet[:1800]

