from datetime import datetime
from pydantic import BaseModel, Field


class DocumentOut(BaseModel):
    id: str
    filename: str
    content_type: str
    page_count: int
    status: str
    storage_uri: str
    created_at: datetime

    class Config:
        from_attributes = True


class QueryRequest(BaseModel):
    question: str = Field(min_length=2)
    session_id: str = "default"
    provider: str | None = None
    document_ids: list[str] | None = None
    filters: dict | None = None
    stream: bool = False


class Citation(BaseModel):
    document_id: str
    document_name: str
    page_number: int
    chunk_id: str
    section_title: str | None = None


class RetrievedChunk(BaseModel):
    chunk_id: str
    document_id: str
    document_name: str
    page_number: int
    section_title: str | None = None
    text: str
    score: float


class QueryResponse(BaseModel):
    answer: str
    citations: list[Citation]
    retrieved_chunks: list[RetrievedChunk]
    latency_ms: float
    session_id: str


class UploadResponse(BaseModel):
    document: DocumentOut
    chunks_indexed: int

