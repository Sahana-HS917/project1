"""Pydantic model package."""

