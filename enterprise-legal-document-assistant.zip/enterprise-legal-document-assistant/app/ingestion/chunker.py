import re
from dataclasses import dataclass

from app.config.settings import get_settings
from app.ingestion.loaders import PageText


@dataclass
class LegalChunk:
    id: str
    document_id: str
    document_name: str
    page_number: int
    section_title: str | None
    text: str
    token_count: int


def token_count(text: str) -> int:
    return max(1, len(re.findall(r"\w+|[^\w\s]", text)))


def split_words(text: str) -> list[str]:
    return re.findall(r"\S+", text)


def build_chunks(document_id: str, document_name: str, pages: list[PageText]) -> list[LegalChunk]:
    settings = get_settings()
    chunks: list[LegalChunk] = []
    ordinal = 0
    for page in pages:
        words = split_words(page.text)
        if not words:
            continue
        start = 0
        while start < len(words):
            end = min(start + settings.chunk_size_tokens, len(words))
            text = " ".join(words[start:end]).strip()
            if text:
                ordinal += 1
                chunks.append(
                    LegalChunk(
                        id=f"{document_id}-{ordinal:05d}",
                        document_id=document_id,
                        document_name=document_name,
                        page_number=page.page_number,
                        section_title=page.section_title,
                        text=text,
                        token_count=token_count(text),
                    )
                )
            if end == len(words):
                break
            start = max(0, end - settings.chunk_overlap_tokens)
    return chunks


def chunk_to_context(chunk: LegalChunk | dict) -> str:
    if isinstance(chunk, dict):
        return (
            f"[{chunk['document_name']} | Page {chunk['page_number']} | Chunk {chunk['chunk_id']}]\n"
            f"Section: {chunk.get('section_title') or 'Unknown'}\n{chunk['text']}"
        )
    return (
        f"[{chunk.document_name} | Page {chunk.page_number} | Chunk {chunk.id}]\n"
        f"Section: {chunk.section_title or 'Unknown'}\n{chunk.text}"
    )

