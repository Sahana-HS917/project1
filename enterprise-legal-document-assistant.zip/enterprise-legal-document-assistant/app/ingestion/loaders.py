from dataclasses import dataclass
from pathlib import Path


@dataclass
class PageText:
    page_number: int
    text: str
    section_title: str | None = None


def load_document(path: str) -> list[PageText]:
    suffix = Path(path).suffix.lower()
    if suffix == ".pdf":
        return load_pdf(path)
    if suffix == ".docx":
        return load_docx(path)
    if suffix == ".txt":
        return load_txt(path)
    raise ValueError(f"Unsupported document type: {suffix}")


def load_pdf(path: str) -> list[PageText]:
    import fitz

    doc = fitz.open(path)
    pages: list[PageText] = []
    for index, page in enumerate(doc, start=1):
        text = page.get_text("text").strip()
        if len(text) < 40:
            text = ocr_pdf_page(page)
        pages.append(PageText(page_number=index, text=text, section_title=infer_section(text)))
    return pages


def ocr_pdf_page(page) -> str:
    try:
        import pytesseract
        from PIL import Image

        pix = page.get_pixmap(dpi=200)
        image = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
        return pytesseract.image_to_string(image).strip()
    except Exception:
        return ""


def load_docx(path: str) -> list[PageText]:
    from docx import Document

    document = Document(path)
    paragraphs = [p.text.strip() for p in document.paragraphs if p.text.strip()]
    text = "\n".join(paragraphs)
    return [PageText(page_number=1, text=text, section_title=infer_section(text))]


def load_txt(path: str) -> list[PageText]:
    text = Path(path).read_text(encoding="utf-8", errors="ignore")
    return [PageText(page_number=1, text=text, section_title=infer_section(text))]


def infer_section(text: str) -> str | None:
    for line in text.splitlines()[:12]:
        clean = line.strip()
        if 4 <= len(clean) <= 120 and (clean.isupper() or clean.lower().startswith(("section", "article", "clause", "exhibit"))):
            return clean
    return None

