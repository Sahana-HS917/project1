from pathlib import Path

from sqlalchemy.orm import Session

from app.ingestion.chunker import build_chunks
from app.ingestion.loaders import load_document
from app.storage.database import Chunk, Document
from app.vectorstore.index import vector_index


class IngestionService:
    def ingest(self, db: Session, document: Document) -> int:
        pages = load_document(document.storage_uri)
        document.page_count = len(pages)
        chunks = build_chunks(document.id, document.filename, pages)
        db.query(Chunk).filter(Chunk.document_id == document.id).delete()
        for chunk in chunks:
            db.add(
                Chunk(
                    id=chunk.id,
                    document_id=chunk.document_id,
                    document_name=chunk.document_name,
                    page_number=chunk.page_number,
                    section_title=chunk.section_title,
                    text=chunk.text,
                    token_count=chunk.token_count,
                )
            )
        document.status = "indexed"
        db.commit()
        vector_index.rebuild(db)
        return len(chunks)

