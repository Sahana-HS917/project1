from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.routes import router
from app.config.settings import get_settings
from app.storage.database import init_db
from app.utils.logging import configure_logging

configure_logging()
settings = get_settings()
init_db()

app = FastAPI(
    title=settings.app_name,
    version="1.0.0",
    description="Context-strict legal RAG assistant for PDFs, DOCX, and TXT documents.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router)

