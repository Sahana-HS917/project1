"""Enterprise Legal Document Assistant application."""

