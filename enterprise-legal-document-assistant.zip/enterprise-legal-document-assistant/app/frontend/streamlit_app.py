import os
import uuid

import requests
import streamlit as st

API_BASE_URL = os.getenv("API_BASE_URL", "http://localhost:8000")
API_KEY = os.getenv("API_KEY", "dev-local-key")

st.set_page_config(page_title="Enterprise Legal Document Assistant", layout="wide")

if "session_id" not in st.session_state:
    st.session_state.session_id = str(uuid.uuid4())
if "messages" not in st.session_state:
    st.session_state.messages = []


def headers():
    return {"X-API-Key": API_KEY}


def api_get(path):
    response = requests.get(f"{API_BASE_URL}{path}", headers=headers(), timeout=30)
    response.raise_for_status()
    return response.json()


def upload_file(file):
    files = {"file": (file.name, file.getvalue(), file.type or "application/octet-stream")}
    response = requests.post(f"{API_BASE_URL}/upload", headers=headers(), files=files, timeout=300)
    response.raise_for_status()
    return response.json()


def ask(question, provider):
    payload = {
        "question": question,
        "session_id": st.session_state.session_id,
        "provider": provider,
        "stream": False,
    }
    response = requests.post(f"{API_BASE_URL}/query", headers=headers(), json=payload, timeout=120)
    response.raise_for_status()
    return response.json()


with st.sidebar:
    st.title("Legal RAG")
    st.caption("Context-only document assistant")
    provider = st.selectbox("Model", ["ollama", "openai", "gemini", "extractive"], index=0)
    dark_mode = st.toggle("Dark mode", value=True)
    uploaded_files = st.file_uploader(
        "Upload PDFs, DOCX, or TXT",
        accept_multiple_files=True,
        type=["pdf", "docx", "txt"],
    )
    if st.button("Process uploads", disabled=not uploaded_files):
        for file in uploaded_files:
            with st.status(f"Indexing {file.name}", expanded=False) as status:
                result = upload_file(file)
                status.update(label=f"Indexed {result['chunks_indexed']} chunks from {file.name}", state="complete")
    if st.button("Rebuild vector index"):
        response = requests.post(f"{API_BASE_URL}/reindex", headers=headers(), timeout=120)
        st.success(response.json())
    st.divider()
    try:
        docs = api_get("/documents")
        st.metric("Documents", len(docs))
        for doc in docs[:20]:
            st.caption(f"{doc['filename']} · {doc['page_count']} pages · {doc['status']}")
    except Exception as exc:
        st.warning(f"API unavailable: {exc}")

if dark_mode:
    st.markdown(
        """
        <style>
        .stApp { background: #111827; color: #f9fafb; }
        [data-testid="stSidebar"] { background: #0f172a; }
        </style>
        """,
        unsafe_allow_html=True,
    )

st.title("Enterprise Legal Document Assistant")
st.caption("Ask questions across uploaded legal documents. Answers are restricted to retrieved evidence and include exact citations.")

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])
        if message.get("sources"):
            with st.expander("Sources"):
                for source in message["sources"]:
                    st.markdown(
                        f"**{source['document_name']} | Page {source['page_number']} | Chunk {source['chunk_id']}**"
                    )
                    st.write(source["text"][:1200])

question = st.chat_input("Ask a question about the uploaded documents")
if question:
    st.session_state.messages.append({"role": "user", "content": question})
    with st.chat_message("user"):
        st.markdown(question)
    with st.chat_message("assistant"):
        placeholder = st.empty()
        with st.spinner("Retrieving, reranking, and validating citations..."):
            result = ask(question, provider)
        placeholder.markdown(result["answer"])
        with st.expander("Source citations and retrieved chunks", expanded=True):
            for chunk in result["retrieved_chunks"]:
                st.markdown(f"**{chunk['document_name']} | Page {chunk['page_number']} | Chunk {chunk['chunk_id']}**")
                st.write(chunk["text"][:1500])
        st.caption(f"Latency: {result['latency_ms']} ms")
    st.session_state.messages.append(
        {
            "role": "assistant",
            "content": result["answer"],
            "sources": result["retrieved_chunks"],
        }
    )
