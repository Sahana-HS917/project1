from fastapi import APIRouter, BackgroundTasks, Depends, File, HTTPException, Request, UploadFile
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app.ingestion.service import IngestionService
from app.models.schemas import DocumentOut, QueryRequest, QueryResponse, UploadResponse
from app.rag.pipeline import LegalRAGPipeline
from app.storage.database import Chunk, Document, get_db
from app.storage.object_store import save_upload
from app.utils.rate_limit import check_rate_limit
from app.utils.security import require_api_key
from app.vectorstore.index import vector_index

router = APIRouter(dependencies=[Depends(require_api_key)])
rag_pipeline = LegalRAGPipeline()
ingestion_service = IngestionService()


def process_document_background(document_id: str) -> None:
    from app.storage.database import SessionLocal

    db = SessionLocal()
    try:
        document = db.get(Document, document_id)
        if document:
            ingestion_service.ingest(db, document)
    except Exception:
        document = db.get(Document, document_id)
        if document:
            document.status = "failed"
            db.commit()
    finally:
        db.close()


@router.get("/health")
def health():
    return {"status": "ok", "service": "legal-rag"}


@router.post("/upload", response_model=UploadResponse)
async def upload_document(
    request: Request,
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    async_mode: bool = False,
    db: Session = Depends(get_db),
):
    check_rate_limit(request)
    try:
        storage_uri, digest = await save_upload(file)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    existing = db.query(Document).filter(Document.sha256 == digest).first()
    if existing:
        return UploadResponse(document=existing, chunks_indexed=db.query(Chunk).filter(Chunk.document_id == existing.id).count())
    document = Document(
        filename=file.filename or "document",
        content_type=file.content_type or "application/octet-stream",
        storage_uri=storage_uri,
        sha256=digest,
        status="processing",
    )
    db.add(document)
    db.commit()
    db.refresh(document)
    if async_mode:
        background_tasks.add_task(process_document_background, document.id)
        return UploadResponse(document=document, chunks_indexed=0)
    try:
        count = ingestion_service.ingest(db, document)
    except Exception as exc:
        document.status = "failed"
        db.commit()
        raise HTTPException(status_code=500, detail=f"Ingestion failed: {exc}") from exc
    db.refresh(document)
    return UploadResponse(document=document, chunks_indexed=count)


@router.post("/query", response_model=QueryResponse)
async def query_documents(request: Request, payload: QueryRequest, db: Session = Depends(get_db)):
    check_rate_limit(request)
    if payload.stream:
        async def token_stream():
            async for token in rag_pipeline.stream_answer(db, payload):
                yield token

        return StreamingResponse(token_stream(), media_type="text/plain")
    return await rag_pipeline.answer(db, payload)


@router.get("/documents", response_model=list[DocumentOut])
def list_documents(db: Session = Depends(get_db)):
    return db.query(Document).order_by(Document.created_at.desc()).all()


@router.delete("/documents/{document_id}")
def delete_document(document_id: str, db: Session = Depends(get_db)):
    document = db.get(Document, document_id)
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")
    db.query(Chunk).filter(Chunk.document_id == document_id).delete()
    db.delete(document)
    db.commit()
    vector_index.rebuild(db)
    return {"deleted": document_id}


@router.post("/reindex")
def reindex(db: Session = Depends(get_db)):
    count = vector_index.rebuild(db)
    return {"status": "rebuilt", "chunks": count}


@router.post("/documents/{document_id}/summary")
async def summarize_document(document_id: str, provider: str | None = None, db: Session = Depends(get_db)):
    chunks = db.query(Chunk).filter(Chunk.document_id == document_id).order_by(Chunk.page_number.asc()).limit(12).all()
    if not chunks:
        raise HTTPException(status_code=404, detail="Document chunks not found")
    request = QueryRequest(
        question="Summarize the key legal obligations, parties, dates, and risks in this document.",
        provider=provider,
        document_ids=[document_id],
    )
    return await rag_pipeline.answer(db, request)


@router.post("/analysis/clause")
async def extract_clause(question: str, provider: str | None = None, db: Session = Depends(get_db)):
    request = QueryRequest(
        question=f"Locate and explain the clause relevant to: {question}",
        provider=provider,
    )
    return await rag_pipeline.answer(db, request)


@router.post("/analysis/risk")
async def contract_risk(question: str = "Identify contract risks.", provider: str | None = None, db: Session = Depends(get_db)):
    request = QueryRequest(
        question=f"Based only on uploaded documents, identify legal or contract risk factors. Focus: {question}",
        provider=provider,
    )
    return await rag_pipeline.answer(db, request)
