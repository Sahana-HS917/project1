import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)

from app.ingestion.chunker import build_chunks
from app.ingestion.loaders import PageText


def test_chunks_preserve_page_and_document_metadata():
    pages = [PageText(page_number=7, text="SECTION 1\n" + "assignment clause " * 1200, section_title="SECTION 1")]
    chunks = build_chunks("doc-1", "Contract.pdf", pages)
    assert chunks
    assert chunks[0].document_name == "Contract.pdf"
    assert chunks[0].page_number == 7
    assert chunks[0].section_title == "SECTION 1"

