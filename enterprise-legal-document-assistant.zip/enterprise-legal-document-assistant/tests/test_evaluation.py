import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)

from app.rag.evaluation import hallucination_detected, precision_at_k, recall_at_k


def test_precision_and_recall():
    expected = {"a", "b"}
    retrieved = ["a", "c", "b"]
    assert precision_at_k(expected, retrieved, 2) == 0.5
    assert recall_at_k(expected, retrieved, 3) == 1.0


def test_hallucination_detection_requires_citations():
    assert hallucination_detected("The contract says assignment is prohibited.", []) is True
    assert hallucination_detected("The documents do not contain enough information to answer this question.", []) is False

