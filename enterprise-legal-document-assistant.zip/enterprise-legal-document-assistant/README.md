# Enterprise Legal Document Assistant

A production-grade RAG-based “Ask My PDF” chatbot for legal firms. It ingests PDFs, scanned PDFs, DOCX, and TXT files; builds FAISS dense indexes plus BM25 sparse indexes; reranks retrieved evidence; answers strictly from uploaded documents; and returns exact citations with document name, page number, and chunk id.

> Legal safety note: this application is an attorney-assistive research tool, not legal advice. It is designed to refuse questions that cannot be answered from uploaded evidence.

## Quick Start

```bash
cp .env.example .env
docker compose up --build
```

Open:

- Streamlit UI: http://localhost:8501
- FastAPI docs: http://localhost:8000/docs

See [docs/runbook.md](docs/runbook.md) for Git Bash, VS Code, local Python, Docker, and Ollama instructions.

For background ingestion of large files, call `/upload?async_mode=true`; the document status changes from `processing` to `indexed` when complete.

## Local Development

```bash
python -m venv .venv
source .venv/Scripts/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

In another terminal:

```bash
streamlit run app/frontend/streamlit_app.py
```

## Key Guarantees

- Answers only from retrieved context.
- Every substantive answer includes citations like `[Contract_ABC.pdf | Page 18 | Chunk doc-...-003]`.
- If retrieved context is insufficient, the system responds exactly:

```text
The uploaded documents do not contain enough information to answer this question.
```

## Architecture

```mermaid
flowchart LR
    U["User"] --> UI["Streamlit UI"]
    UI --> API["FastAPI"]
    API --> ING["Ingestion Service"]
    ING --> OCR["OCR + Parsers"]
    OCR --> CH["Legal Chunker"]
    CH --> EMB["Embedding Cache"]
    EMB --> VS["FAISS Index"]
    CH --> BM["BM25 Index"]
    API --> RAG["LangGraph-style RAG Pipeline"]
    RAG --> RET["Hybrid Retrieval"]
    RET --> RR["Cross-Encoder Reranker"]
    RR --> LLM["Gemini / OpenAI / Ollama / Extractive Fallback"]
    LLM --> VAL["Citation Validator"]
    VAL --> UI
    API --> DB["SQLite Metadata"]
    ING --> S3["Local Storage or S3"]
```

## Folder Map

```text
app/
  api/          FastAPI routers
  config/       Settings and prompts
  frontend/     Streamlit UI
  ingestion/    PDF/DOCX/TXT/OCR extraction and chunking
  models/       Pydantic schemas
  rag/          Query rewriting, retrieval, reranking, generation, validation
  storage/      SQLite metadata and file storage
  utils/        Logging, security, rate limiting
  vectorstore/  FAISS, BM25, embedding cache
data/           Local runtime storage
docs/           Architecture and AWS deployment
scripts/        CLI helpers
tests/          Unit and API tests
```

## Why These Libraries

- FastAPI: typed, async-friendly API surface with OpenAPI docs.
- Streamlit: fast internal legal tooling UI with file upload and streaming chat.
- PyMuPDF/pdfplumber: high-quality PDF text and metadata extraction.
- pytesseract: OCR path for scanned PDFs.
- python-docx: DOCX ingestion.
- sentence-transformers: strong local embeddings and reranking.
- FAISS: fast local vector search, simple AWS free-tier deployment.
- rank-bm25: sparse keyword retrieval for legal exact-match terms.
- LangChain/LangGraph: orchestration compatibility for teams already standardizing on RAG workflows.
- SQLite: lightweight metadata store for free-tier/single-node deployments.
- Ollama: offline LLM support.

## Performance Notes

- Use `all-MiniLM-L6-v2` for low memory and low latency.
- Use `BAAI/bge-base-en-v1.5` for better retrieval quality at higher CPU cost.
- Keep chunk size between 800 and 1200 tokens with 150 to 200 token overlap.
- Enable reranking for legal precision; disable it only for very small machines.
- For 500,000+ pages, shard indexes by matter/client/date and use metadata filters.

## Bonus Capabilities

- Embedding cache for semantic reuse.
- Source highlighting through expandable retrieved chunks.
- Document summarization endpoint.
- Legal clause extraction endpoint.
- Contract risk analysis endpoint.
- LangGraph-compatible graph skeleton for agentic retrieval expansion.
