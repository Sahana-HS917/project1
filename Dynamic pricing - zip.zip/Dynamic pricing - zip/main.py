"""
Main entry point for Dynamic Pricing Engine
Orchestrates data generation, model training, and API startup
"""
import sys
import argparse
from pathlib import Path
import pandas as pd
import numpy as np
from datetime import datetime

# Add src to path
sys.path.insert(0, str(Path(__file__).parent))

from src.utils.logger import Logger
from src.utils.config import settings
from src.ingestion.data_generator import SyntheticDataGenerator
from src.preprocessing.data_preprocessor import DataPreprocessor
from src.feature_engineering.feature_engineer import FeatureEngineer
from src.forecasting.demand_forecaster import DemandForecaster
from src.optimization.revenue_optimizer import RevenueOptimizer
from src.optimization.elasticity_analyzer import PriceElasticityAnalyzer

logger = Logger.get_logger(__name__)


def generate_data(n_records: int = 100000) -> tuple:
    """Generate synthetic data"""
    logger.info(f"Generating {n_records} synthetic records")
    
    generator = SyntheticDataGenerator(seed=42)
    pricing_df, competitor_df = generator.generate_all(n_records=n_records)
    
    return pricing_df, competitor_df


def preprocess_data(pricing_df: pd.DataFrame) -> pd.DataFrame:
    """Preprocess data"""
    logger.info("Preprocessing data")
    
    preprocessor = DataPreprocessor()
    cleaned_df = preprocessor.preprocess(pricing_df)
    
    return cleaned_df


def engineer_features(cleaned_df: pd.DataFrame) -> pd.DataFrame:
    """Engineer features"""
    logger.info("Engineering features")
    
    engineer = FeatureEngineer(scaling_method='standard')
    feature_df = engineer.engineer_features(cleaned_df)
    
    return feature_df


def train_models(feature_df: pd.DataFrame) -> dict:
    """Train forecasting models"""
    logger.info("Training forecasting models")
    
    forecaster = DemandForecaster(forecast_horizon=30)
    timeseries_df = forecaster.prepare_timeseries_data(feature_df, target_col='demand')
    
    if len(timeseries_df) > 50:
        results = forecaster.train_all_models(timeseries_df, target_col='demand')
        logger.info(f"Best forecasting model: {results['best_model_name']}")
    else:
        logger.warning("Insufficient data for training models")
        results = {}
    
    return results


def demonstrate_pricing_optimization():
    """Demonstrate pricing optimization"""
    logger.info("Demonstrating pricing optimization")
    
    optimizer = RevenueOptimizer()
    
    # Example products
    example_products = [
        {
            'product_id': 1001,
            'base_price': 1000,
            'current_price': 950,
            'category': 'Electronics'
        },
        {
            'product_id': 1002,
            'base_price': 150,
            'current_price': 140,
            'category': 'Fashion'
        },
        {
            'product_id': 1003,
            'base_price': 500,
            'current_price': 480,
            'category': 'Home'
        }
    ]
    
    for product in example_products:
        market_conditions = {
            'competitor_price': product['current_price'] * np.random.uniform(0.9, 1.1),
            'inventory_level': np.random.randint(20, 200),
            'demand_trend': np.random.uniform(0.8, 1.5),
            'elasticity': -1.8
        }
        
        forecast_data = {
            'demand_forecast': np.random.randint(50, 150),
            'price_elasticity': -1.8,
            'trend': np.random.choice(['trending_up', 'stable', 'trending_down'])
        }
        
        recommendation = optimizer.optimize_price(product, market_conditions, forecast_data)
        
        print(f"\n{'='*60}")
        print(f"Product: {product['product_id']}")
        print(f"Current Price: ${recommendation['current_price']:.2f}")
        print(f"Recommended Price: ${recommendation['recommended_price']:.2f}")
        print(f"Price Change: {recommendation['price_change_pct']:.2f}%")
        print(f"Expected Revenue Lift: {recommendation['revenue_lift_pct']:.2f}%")
        print(f"Confidence: {recommendation['confidence_score']:.1f}%")
        print(f"Reason: {recommendation['recommendation_reason']}")


def main():
    """Main function"""
    parser = argparse.ArgumentParser(description="Dynamic Pricing Engine")
    parser.add_argument(
        '--mode',
        choices=['generate', 'preprocess', 'engineer', 'train', 'optimize', 'api', 'dashboard', 'full'],
        default='full',
        help='Operation mode'
    )
    parser.add_argument(
        '--records',
        type=int,
        default=100000,
        help='Number of records to generate'
    )
    parser.add_argument(
        '--api-port',
        type=int,
        default=8000,
        help='API port'
    )
    
    args = parser.parse_args()
    
    logger.info(f"Starting Dynamic Pricing Engine - Mode: {args.mode}")
    logger.info(f"Settings: min_price=${settings.PRICE_MIN_THRESHOLD}, max_price=${settings.PRICE_MAX_THRESHOLD}")
    
    try:
        if args.mode in ['generate', 'full']:
            pricing_df, competitor_df = generate_data(n_records=args.records)
        
        if args.mode in ['preprocess', 'full']:
            if 'pricing_df' not in locals():
                pricing_df, _ = generate_data(n_records=args.records)
            
            cleaned_df = preprocess_data(pricing_df)
        
        if args.mode in ['engineer', 'full']:
            if 'cleaned_df' not in locals():
                pricing_df, _ = generate_data(n_records=args.records)
                cleaned_df = preprocess_data(pricing_df)
            
            feature_df = engineer_features(cleaned_df)
        
        if args.mode in ['train', 'full']:
            if 'feature_df' not in locals():
                pricing_df, _ = generate_data(n_records=args.records)
                cleaned_df = preprocess_data(pricing_df)
                feature_df = engineer_features(cleaned_df)
            
            models = train_models(feature_df)
        
        if args.mode in ['optimize', 'full']:
            demonstrate_pricing_optimization()
        
        if args.mode == 'api' or (args.mode == 'full'):
            logger.info(f"To start the API, run: uvicorn src.api.main:app --host 0.0.0.0 --port {args.api_port}")
        
        if args.mode == 'dashboard' or (args.mode == 'full'):
            logger.info("To start the dashboard, run: streamlit run src/frontend/dashboard.py")
        
        logger.info("✅ Dynamic Pricing Engine execution complete!")
    
    except Exception as e:
        logger.error(f"❌ Error: {str(e)}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
