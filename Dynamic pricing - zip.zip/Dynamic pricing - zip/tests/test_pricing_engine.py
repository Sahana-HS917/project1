"""
Unit tests for Dynamic Pricing Engine
"""
import pytest
import pandas as pd
import numpy as np
from datetime import datetime

from src.ingestion.data_generator import SyntheticDataGenerator
from src.preprocessing.data_preprocessor import DataPreprocessor
from src.feature_engineering.feature_engineer import FeatureEngineer
from src.optimization.revenue_optimizer import RevenueOptimizer
from src.optimization.elasticity_analyzer import PriceElasticityAnalyzer


class TestDataGeneration:
    """Test data generation"""
    
    def test_data_generator_creates_products(self):
        """Test product catalog generation"""
        generator = SyntheticDataGenerator(seed=42)
        products = generator.generate_products_catalog(n_products=50)
        
        assert len(products) == 50
        assert 'product_id' in products.columns
        assert 'base_price' in products.columns
        assert products['base_price'].min() > 0
    
    def test_data_generator_creates_pricing_data(self):
        """Test pricing data generation"""
        generator = SyntheticDataGenerator(seed=42)
        pricing_df = generator.generate_pricing_data(n_records=1000)
        
        assert len(pricing_df) == 1000
        assert 'timestamp' in pricing_df.columns
        assert 'current_price' in pricing_df.columns
        assert 'demand' in pricing_df.columns
        assert pricing_df['current_price'].min() > 0
        assert pricing_df['demand'].min() > 0


class TestDataPreprocessing:
    """Test data preprocessing"""
    
    def test_preprocessor_handles_missing_values(self):
        """Test missing value handling"""
        df = pd.DataFrame({
            'product_id': [1, 2, 3, 4, 5],
            'price': [100, np.nan, 300, 400, 500],
            'demand': [10, 20, 30, np.nan, 50]
        })
        
        preprocessor = DataPreprocessor()
        cleaned_df = preprocessor.handle_missing_values(df)
        
        assert cleaned_df['price'].isnull().sum() == 0
        assert cleaned_df['demand'].isnull().sum() == 0
    
    def test_preprocessor_removes_duplicates(self):
        """Test duplicate removal"""
        df = pd.DataFrame({
            'product_id': [1, 1, 2, 3, 3],
            'timestamp': ['2024-01-01', '2024-01-01', '2024-01-01', '2024-01-01', '2024-01-01'],
            'price': [100, 100, 200, 300, 300]
        })
        
        preprocessor = DataPreprocessor()
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        cleaned_df = preprocessor.remove_duplicates(df)
        
        assert len(cleaned_df) < len(df)


class TestFeatureEngineering:
    """Test feature engineering"""
    
    def test_feature_engineer_creates_temporal_features(self):
        """Test temporal feature creation"""
        df = pd.DataFrame({
            'timestamp': pd.date_range('2024-01-01', periods=100, freq='H'),
            'price': np.random.uniform(100, 1000, 100),
            'demand': np.random.randint(10, 100, 100)
        })
        
        engineer = FeatureEngineer()
        feature_df = engineer.create_temporal_features(df)
        
        assert 'hour' in feature_df.columns
        assert 'day_of_week' in feature_df.columns
        assert 'is_holiday' in feature_df.columns
        assert 'hour_sin' in feature_df.columns
        assert 'hour_cos' in feature_df.columns
    
    def test_feature_engineer_creates_demand_features(self):
        """Test demand feature creation"""
        df = pd.DataFrame({
            'product_id': [1, 1, 1, 1, 1, 2, 2, 2, 2, 2],
            'purchases': [10, 12, 15, 14, 16, 20, 22, 25, 24, 26],
            'revenue': [1000, 1200, 1500, 1400, 1600, 2000, 2200, 2500, 2400, 2600],
            'demand': [15, 18, 20, 19, 21, 25, 28, 30, 29, 32]
        })
        
        engineer = FeatureEngineer()
        feature_df = engineer.create_demand_features(df)
        
        assert 'sales_ma_7' in feature_df.columns
        assert 'revenue_ma_7' in feature_df.columns
        assert 'cart_conversion_rate' in feature_df.columns


class TestRevenueOptimization:
    """Test revenue optimization"""
    
    def test_optimizer_calculates_stockout_risk(self):
        """Test stockout risk calculation"""
        optimizer = RevenueOptimizer()
        
        risk_high = optimizer.calculate_stockout_risk(inventory=10, expected_demand=50)
        risk_low = optimizer.calculate_stockout_risk(inventory=500, expected_demand=50)
        
        assert risk_high > risk_low
        assert 0 <= risk_high <= 1
        assert 0 <= risk_low <= 1
    
    def test_optimizer_calculates_demand_impact(self):
        """Test demand impact calculation"""
        optimizer = RevenueOptimizer()
        
        multiplier = optimizer.calculate_demand_impact(
            elasticity=-1.5,
            current_price=100,
            proposed_price=110
        )
        
        assert multiplier > 0
        assert multiplier < 1  # Demand should decrease with price increase
    
    def test_optimizer_generates_price_recommendation(self):
        """Test price recommendation"""
        optimizer = RevenueOptimizer()
        
        product_info = {
            'product_id': 1001,
            'base_price': 1000,
            'current_price': 950,
            'category': 'Electronics'
        }
        
        market_conditions = {
            'competitor_price': 1100,
            'inventory_level': 100,
            'demand_trend': 1.2,
            'elasticity': -1.8
        }
        
        forecast_data = {
            'demand_forecast': 100,
            'price_elasticity': -1.8,
            'trend': 'trending_up'
        }
        
        recommendation = optimizer.optimize_price(product_info, market_conditions, forecast_data)
        
        assert recommendation['recommended_price'] > 0
        assert 'revenue_lift_pct' in recommendation
        assert 'confidence_score' in recommendation
        assert 0 <= recommendation['confidence_score'] <= 100


class TestPriceElasticity:
    """Test price elasticity analysis"""
    
    def test_elasticity_analyzer_calculates_elasticity(self):
        """Test elasticity calculation"""
        df = pd.DataFrame({
            'price': [100, 110, 120, 130, 140],
            'demand': [100, 90, 80, 70, 60]
        })
        
        analyzer = PriceElasticityAnalyzer()
        elasticity = analyzer.calculate_elasticity(df, price_col='price', demand_col='demand')
        
        assert 'overall' in elasticity
        assert elasticity['overall'] < 0  # Normal negative elasticity
    
    def test_elasticity_analyzer_generates_optimal_price(self):
        """Test optimal price estimation"""
        analyzer = PriceElasticityAnalyzer()
        
        optimal_price = analyzer.estimate_optimal_price(
            base_price=100,
            elasticity=-1.5,
            cost=40,
            target_margin=0.25
        )
        
        assert optimal_price > 40  # Should be above cost
        assert optimal_price > 0


@pytest.fixture
def sample_data():
    """Generate sample data for tests"""
    generator = SyntheticDataGenerator(seed=42)
    return generator.generate_pricing_data(n_records=1000)


@pytest.fixture
def cleaned_data(sample_data):
    """Generate cleaned data"""
    preprocessor = DataPreprocessor()
    return preprocessor.preprocess(sample_data)


def test_end_to_end_pipeline(sample_data):
    """Test end-to-end pipeline"""
    # Preprocess
    preprocessor = DataPreprocessor()
    cleaned_df = preprocessor.preprocess(sample_data)
    
    assert len(cleaned_df) > 0
    assert cleaned_df['current_price'].min() > 0
    
    # Engineer features
    engineer = FeatureEngineer()
    feature_df = engineer.engineer_features(cleaned_df)
    
    assert len(feature_df) > 0
    assert len(feature_df.columns) > len(cleaned_df.columns)
    
    # Optimize pricing
    optimizer = RevenueOptimizer()
    sample_product = feature_df.iloc[0]
    
    recommendation = optimizer.optimize_price(
        sample_product.to_dict(),
        {
            'competitor_price': sample_product.get('competitor_price', 100),
            'inventory_level': int(sample_product.get('inventory_level', 100)),
            'elasticity': sample_product.get('elasticity', -1.5)
        },
        {
            'demand_forecast': sample_product.get('demand', 50),
            'price_elasticity': sample_product.get('elasticity', -1.5),
            'trend': 'stable'
        }
    )
    
    assert recommendation['recommended_price'] > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
