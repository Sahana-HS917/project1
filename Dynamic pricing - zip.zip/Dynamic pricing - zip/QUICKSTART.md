# Quick Start Guide

## 🚀 5-Minute Setup

### Option 1: Docker (Easiest)

```bash
# Navigate to project
cd dynamic-pricing-engine

# Start all services
docker-compose up -d

# Wait for services to start (30-60 seconds)
sleep 30

# Check services
docker-compose ps

# Access services
# API: http://localhost:8000
# Dashboard: http://localhost:8501
# Grafana: http://localhost:3000 (admin/admin)
```

### Option 2: Local Development

```bash
# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Generate sample data
python main.py --mode generate --records 100000

# Terminal 1: Start API
python -m uvicorn src.api.main:app --reload

# Terminal 2: Start Dashboard
streamlit run src/frontend/dashboard.py

# Terminal 3: Run engine
python main.py --mode optimize
```

---

## 📊 Dashboard Access

| Component | URL | Credentials |
|-----------|-----|-------------|
| API Docs | `http://localhost:8000/docs` | None |
| Dashboard | `http://localhost:8501` | None |
| Grafana | `http://localhost:3000` | admin/admin |
| Prometheus | `http://localhost:9090` | None |

---

## 🔧 First API Call

```bash
curl -X POST "http://localhost:8000/predict-price" \
  -H "Content-Type: application/json" \
  -d '{
    "product": {
      "product_id": 1001,
      "base_price": 1000,
      "current_price": 950,
      "category": "Electronics"
    },
    "market_conditions": {
      "competitor_price": 1100,
      "inventory_level": 50,
      "demand_trend": 1.2,
      "elasticity": -1.8
    },
    "forecast": {
      "demand_forecast": 100,
      "price_elasticity": -1.8,
      "trend": "trending_up"
    }
  }'
```

---

## 📁 Key Files to Explore

```
main.py                    # Entry point - run the entire pipeline
src/api/main.py           # FastAPI backend
src/frontend/dashboard.py # Streamlit dashboard
src/optimization/         # Core pricing algorithms
README.md                 # Full documentation
deployment/               # Deployment guides
```

---

## 🧪 Run Tests

```bash
# All tests
pytest tests/ -v

# Specific test
pytest tests/test_pricing_engine.py::TestRevenueOptimization -v

# With coverage
pytest tests/ --cov=src
```

---

## 🛑 Stop Services

```bash
# Stop Docker services
docker-compose down

# Remove volumes (clean slate)
docker-compose down -v
```

---

## 📚 Next Steps

1. **Explore the Dashboard** - Visit http://localhost:8501
2. **Read Full README** - `README.md`
3. **Try API Examples** - `deployment/API_EXAMPLES.md`
4. **Deploy to AWS** - `deployment/AWS_DEPLOYMENT.md`
5. **Customize Config** - `src/utils/config.py`

---

## 💡 Common Tasks

### Generate More Data
```bash
python main.py --mode generate --records 500000
```

### Train Models
```bash
python main.py --mode train
```

### Optimize Pricing
```bash
python main.py --mode optimize
```

### Full Pipeline
```bash
python main.py --mode full
```

---

## 🐛 Troubleshooting

### Port Already in Use
```bash
# Change port in docker-compose.yml or:
lsof -i :8000  # Find what's using port 8000
kill -9 <PID>
```

### Out of Memory
```bash
# Reduce data size
python main.py --mode generate --records 10000

# Or increase Docker memory
# Docker Desktop → Preferences → Resources
```

### API Not Responding
```bash
# Check logs
docker-compose logs api

# Restart API
docker-compose restart api
```

---

## 📞 Support

- **Issues**: Check GitHub Issues
- **Docs**: See README.md
- **Examples**: See deployment/API_EXAMPLES.md
- **Help**: Open a GitHub Discussion

---

**Version: 1.0.0 | Last Updated: May 2024**
