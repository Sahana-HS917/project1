"""
Demand forecasting models for pricing optimization
Implements XGBoost, LightGBM, and Prophet for demand prediction
"""
import pandas as pd
import numpy as np
from typing import Tuple, Dict, Any, List
import joblib
from datetime import datetime, timedelta

from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, mean_absolute_percentage_error
import xgboost as xgb
import lightgbm as lgb
from sklearn.ensemble import RandomForestRegressor
from statsmodels.tsa.seasonal import seasonal_decompose
from src.utils.logger import Logger

logger = Logger.get_logger(__name__)


class DemandForecaster:
    """Forecast product demand using multiple models"""
    
    def __init__(self, forecast_horizon: int = 30):
        """
        Initialize forecaster
        
        Args:
            forecast_horizon: Number of days to forecast ahead
        """
        self.forecast_horizon = forecast_horizon
        self.models = {}
        self.scalers = {}
        self.metrics = {}
        
    def prepare_timeseries_data(self, df: pd.DataFrame, product_id: int = None, 
                               target_col: str = 'demand') -> pd.DataFrame:
        """
        Prepare time series data for forecasting
        
        Args:
            df: Input DataFrame with timestamp and demand columns
            product_id: Specific product to forecast (optional)
            target_col: Column to forecast ('demand', 'purchases', 'revenue')
            
        Returns:
            Prepared time series DataFrame
        """
        logger.info(f"Preparing time series data for {target_col}")
        
        df = df.sort_values('timestamp').reset_index(drop=True)
        
        if product_id is not None:
            df = df[df['product_id'] == product_id].copy()
        
        # Aggregate by day
        df['date'] = pd.to_datetime(df['timestamp']).dt.date
        daily_df = df.groupby('date').agg({
            target_col: 'sum',
            'purchases': 'sum' if target_col != 'purchases' else 'sum',
            'revenue': 'sum' if target_col != 'revenue' else 'sum',
            'inventory_level': 'mean',
            'competitor_price': 'mean',
            'current_price': 'mean',
        }).reset_index()
        
        daily_df['date'] = pd.to_datetime(daily_df['date'])
        daily_df = daily_df.sort_values('date').reset_index(drop=True)
        
        logger.info(f"Prepared {len(daily_df)} daily records")
        return daily_df
    
    def train_xgboost_model(self, X_train: pd.DataFrame, y_train: pd.Series,
                           X_val: pd.DataFrame = None, y_val: pd.Series = None) -> xgb.XGBRegressor:
        """
        Train XGBoost demand forecasting model
        
        Args:
            X_train: Training features
            y_train: Training target
            X_val: Validation features
            y_val: Validation target
            
        Returns:
            Trained XGBoost model
        """
        logger.info("Training XGBoost model")
        
        model = xgb.XGBRegressor(
            n_estimators=200,
            max_depth=7,
            learning_rate=0.1,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=42,
            n_jobs=-1,
            tree_method='hist'
        )
        
        eval_set = [(X_val, y_val)] if X_val is not None and y_val is not None else None
        
        model.fit(
            X_train, y_train,
            eval_set=eval_set,
            verbose=False,
            early_stopping_rounds=20 if eval_set else None
        )
        
        logger.info("XGBoost training complete")
        return model
    
    def train_lightgbm_model(self, X_train: pd.DataFrame, y_train: pd.Series,
                            X_val: pd.DataFrame = None, y_val: pd.Series = None) -> lgb.LGBMRegressor:
        """
        Train LightGBM demand forecasting model
        
        Args:
            X_train: Training features
            y_train: Training target
            X_val: Validation features
            y_val: Validation target
            
        Returns:
            Trained LightGBM model
        """
        logger.info("Training LightGBM model")
        
        model = lgb.LGBMRegressor(
            n_estimators=200,
            max_depth=7,
            learning_rate=0.1,
            num_leaves=31,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=42,
            n_jobs=-1
        )
        
        model.fit(
            X_train, y_train,
            eval_set=[(X_val, y_val)] if X_val is not None else None,
            callbacks=[lgb.early_stopping(20, verbose=False)] if X_val is not None else None
        )
        
        logger.info("LightGBM training complete")
        return model
    
    def train_random_forest_model(self, X_train: pd.DataFrame, y_train: pd.Series) -> RandomForestRegressor:
        """
        Train Random Forest demand forecasting model
        
        Args:
            X_train: Training features
            y_train: Training target
            
        Returns:
            Trained Random Forest model
        """
        logger.info("Training Random Forest model")
        
        model = RandomForestRegressor(
            n_estimators=200,
            max_depth=15,
            min_samples_split=10,
            min_samples_leaf=5,
            random_state=42,
            n_jobs=-1
        )
        
        model.fit(X_train, y_train)
        
        logger.info("Random Forest training complete")
        return model
    
    def evaluate_model(self, model, X_test: pd.DataFrame, y_test: pd.Series, model_name: str) -> Dict[str, float]:
        """
        Evaluate model performance
        
        Args:
            model: Trained model
            X_test: Test features
            y_test: Test target
            model_name: Name of the model
            
        Returns:
            Dictionary of metrics
        """
        y_pred = model.predict(X_test)
        
        mae = mean_absolute_error(y_test, y_pred)
        rmse = np.sqrt(mean_squared_error(y_test, y_pred))
        mape = mean_absolute_percentage_error(y_test, y_pred)
        
        metrics = {
            'mae': mae,
            'rmse': rmse,
            'mape': mape,
        }
        
        logger.info(f"{model_name} Metrics - MAE: {mae:.4f}, RMSE: {rmse:.4f}, MAPE: {mape:.4f}")
        
        return metrics
    
    def create_lag_features(self, df: pd.DataFrame, target_col: str, lags: List[int] = [1, 7, 14, 30]) -> pd.DataFrame:
        """
        Create lag features for time series prediction
        
        Args:
            df: Time series DataFrame
            target_col: Column to create lags for
            lags: List of lag periods
            
        Returns:
            DataFrame with lag features
        """
        for lag in lags:
            df[f'{target_col}_lag_{lag}'] = df[target_col].shift(lag)
        
        df = df.dropna()
        return df
    
    def train_all_models(self, df: pd.DataFrame, target_col: str = 'demand',
                        feature_cols: List[str] = None) -> Dict[str, Any]:
        """
        Train all forecasting models and compare
        
        Args:
            df: Input DataFrame with features
            target_col: Target column to forecast
            feature_cols: Feature columns to use
            
        Returns:
            Dictionary with models and metrics
        """
        logger.info("Training all demand forecasting models")
        
        if feature_cols is None:
            feature_cols = [col for col in df.columns if col not in ['date', 'timestamp', target_col]]
        
        X = df[feature_cols].fillna(0)
        y = df[target_col]
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42
        )
        
        X_train, X_val, y_train, y_val = train_test_split(
            X_train, y_train, test_size=0.2, random_state=42
        )
        
        results = {}
        
        # XGBoost
        xgb_model = self.train_xgboost_model(X_train, y_train, X_val, y_val)
        xgb_metrics = self.evaluate_model(xgb_model, X_test, y_test, "XGBoost")
        results['xgboost'] = {'model': xgb_model, 'metrics': xgb_metrics}
        
        # LightGBM
        lgb_model = self.train_lightgbm_model(X_train, y_train, X_val, y_val)
        lgb_metrics = self.evaluate_model(lgb_model, X_test, y_test, "LightGBM")
        results['lightgbm'] = {'model': lgb_model, 'metrics': lgb_metrics}
        
        # Random Forest
        rf_model = self.train_random_forest_model(X_train, y_train)
        rf_metrics = self.evaluate_model(rf_model, X_test, y_test, "Random Forest")
        results['random_forest'] = {'model': rf_model, 'metrics': rf_metrics}
        
        # Select best model
        best_model_name = min(results.keys(), key=lambda x: results[x]['metrics']['mape'])
        logger.info(f"Best model: {best_model_name}")
        
        results['best_model_name'] = best_model_name
        results['best_model'] = results[best_model_name]['model']
        results['feature_columns'] = feature_cols
        
        return results
    
    def forecast_demand(self, model, df: pd.DataFrame, feature_cols: List[str],
                       steps: int = None) -> pd.DataFrame:
        """
        Make future demand predictions
        
        Args:
            model: Trained forecasting model
            df: Historical data for context
            feature_cols: Feature columns used in training
            steps: Number of steps to forecast
            
        Returns:
            DataFrame with forecasts
        """
        if steps is None:
            steps = self.forecast_horizon
        
        logger.info(f"Forecasting demand for {steps} steps ahead")
        
        # Prepare features for forecast
        last_date = df['date'].max() if 'date' in df.columns else df['timestamp'].max()
        
        forecast_dates = pd.date_range(start=last_date + timedelta(days=1), periods=steps, freq='D')
        
        # Use last known values for features
        last_row = df[feature_cols].iloc[-1:]
        
        forecasts = []
        for date in forecast_dates:
            # Repeat last known features (simple approach)
            X_pred = pd.DataFrame([last_row.values[0]], columns=feature_cols)
            pred = model.predict(X_pred)[0]
            
            forecasts.append({
                'date': date,
                'forecast_demand': max(0, pred),  # Ensure non-negative
            })
        
        forecast_df = pd.DataFrame(forecasts)
        logger.info(f"Generated {len(forecast_df)} forecast records")
        
        return forecast_df
    
    def save_model(self, model, model_name: str, model_type: str = 'demand') -> None:
        """
        Save trained model
        
        Args:
            model: Model to save
            model_name: Name for the model
            model_type: Type of model
        """
        from src.utils.config import settings
        
        model_path = settings.MODELS_DIR / f"{model_type}_{model_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pkl"
        joblib.dump(model, model_path)
        logger.info(f"Model saved to {model_path}")
    
    def load_model(self, model_path: str):
        """
        Load saved model
        
        Args:
            model_path: Path to saved model
            
        Returns:
            Loaded model
        """
        model = joblib.load(model_path)
        logger.info(f"Model loaded from {model_path}")
        return model


if __name__ == "__main__":
    # Example usage
    from src.ingestion.data_generator import SyntheticDataGenerator
    from src.preprocessing.data_preprocessor import DataPreprocessor
    from src.feature_engineering.feature_engineer import FeatureEngineer
    
    # Generate and prepare data
    generator = SyntheticDataGenerator()
    pricing_df, _ = generator.generate_all(n_records=10000)
    
    preprocessor = DataPreprocessor()
    cleaned_df = preprocessor.preprocess(pricing_df)
    
    engineer = FeatureEngineer()
    feature_df = engineer.engineer_features(cleaned_df)
    
    # Forecast demand
    forecaster = DemandForecaster(forecast_horizon=30)
    timeseries_df = forecaster.prepare_timeseries_data(feature_df)
    
    # Create lag features
    timeseries_df = forecaster.create_lag_features(timeseries_df, 'demand', lags=[1, 7, 14])
    
    # Train models
    results = forecaster.train_all_models(timeseries_df)
    
    print("\n=== Demand Forecasting Results ===")
    print(f"Best Model: {results['best_model_name']}")
    print("\nModel Metrics:")
    for model_name, result in results.items():
        if model_name != 'best_model_name' and model_name != 'best_model' and model_name != 'feature_columns':
            print(f"{model_name}: {result['metrics']}")
