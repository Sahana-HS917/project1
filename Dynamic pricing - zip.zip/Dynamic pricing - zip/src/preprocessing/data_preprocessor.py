"""
Data preprocessing module for cleaning and validating pricing data
"""
import pandas as pd
import numpy as np
from typing import Tuple, Dict, Any
from src.utils.logger import Logger

logger = Logger.get_logger(__name__)


class DataPreprocessor:
    """Handle data cleaning, validation, and preprocessing"""
    
    def __init__(self):
        """Initialize preprocessor"""
        self.missing_value_strategy = 'forward_fill'  # forward_fill, mean, median
        self.duplicate_strategy = 'keep_latest'  # keep_latest, remove_all
        
    def validate_data(self, df: pd.DataFrame) -> Tuple[pd.DataFrame, Dict[str, Any]]:
        """
        Validate data quality and return report
        
        Args:
            df: Input DataFrame
            
        Returns:
            Tuple of (cleaned_df, validation_report)
        """
        logger.info("Starting data validation")
        
        report = {
            'total_rows': len(df),
            'total_columns': len(df.columns),
            'duplicates_found': df.duplicated().sum(),
            'missing_values': df.isnull().sum().to_dict(),
        }
        
        # Check for required columns
        required_columns = [
            'timestamp', 'product_id', 'current_price', 'competitor_price',
            'inventory_level', 'purchases', 'demand'
        ]
        
        missing_cols = [col for col in required_columns if col not in df.columns]
        if missing_cols:
            logger.warning(f"Missing required columns: {missing_cols}")
            report['missing_columns'] = missing_cols
        
        # Data type validation
        df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')
        
        logger.info(f"Validation report: {report}")
        return df, report
    
    def handle_missing_values(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Handle missing values in dataset
        
        Args:
            df: Input DataFrame
            
        Returns:
            DataFrame with missing values handled
        """
        logger.info(f"Handling missing values using {self.missing_value_strategy} strategy")
        
        numeric_columns = df.select_dtypes(include=[np.number]).columns
        
        if self.missing_value_strategy == 'forward_fill':
            df[numeric_columns] = df[numeric_columns].fillna(method='ffill').fillna(method='bfill')
        elif self.missing_value_strategy == 'mean':
            df[numeric_columns] = df[numeric_columns].fillna(df[numeric_columns].mean())
        elif self.missing_value_strategy == 'median':
            df[numeric_columns] = df[numeric_columns].fillna(df[numeric_columns].median())
        
        # Fill categorical with mode or 'Unknown'
        categorical_columns = df.select_dtypes(include=['object']).columns
        for col in categorical_columns:
            df[col] = df[col].fillna(df[col].mode()[0] if len(df[col].mode()) > 0 else 'Unknown')
        
        logger.info(f"Missing values after handling: {df.isnull().sum().sum()}")
        return df
    
    def remove_duplicates(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Remove duplicate records
        
        Args:
            df: Input DataFrame
            
        Returns:
            DataFrame with duplicates removed
        """
        logger.info(f"Removing duplicates using {self.duplicate_strategy} strategy")
        
        initial_len = len(df)
        
        if self.duplicate_strategy == 'keep_latest':
            df = df.sort_values('timestamp').drop_duplicates(
                subset=['product_id', 'timestamp'],
                keep='last'
            )
        elif self.duplicate_strategy == 'remove_all':
            df = df.drop_duplicates()
        
        logger.info(f"Removed {initial_len - len(df)} duplicate records")
        return df
    
    def handle_outliers(self, df: pd.DataFrame, method: str = 'iqr') -> pd.DataFrame:
        """
        Detect and handle outliers
        
        Args:
            df: Input DataFrame
            method: Outlier detection method ('iqr' or 'zscore')
            
        Returns:
            DataFrame with outliers handled
        """
        logger.info(f"Handling outliers using {method} method")
        
        numeric_columns = df.select_dtypes(include=[np.number]).columns
        
        if method == 'iqr':
            for col in numeric_columns:
                Q1 = df[col].quantile(0.25)
                Q3 = df[col].quantile(0.75)
                IQR = Q3 - Q1
                lower_bound = Q1 - 1.5 * IQR
                upper_bound = Q3 + 1.5 * IQR
                
                outlier_count = ((df[col] < lower_bound) | (df[col] > upper_bound)).sum()
                
                # Cap outliers instead of removing
                df[col] = df[col].clip(lower_bound, upper_bound)
                
                if outlier_count > 0:
                    logger.info(f"Found {outlier_count} outliers in {col}")
        
        elif method == 'zscore':
            for col in numeric_columns:
                z_scores = np.abs((df[col] - df[col].mean()) / df[col].std())
                outlier_count = (z_scores > 3).sum()
                
                # Cap outliers
                df[col] = df[col].clip(
                    df[col].mean() - 3 * df[col].std(),
                    df[col].mean() + 3 * df[col].std()
                )
                
                if outlier_count > 0:
                    logger.info(f"Found {outlier_count} outliers in {col}")
        
        return df
    
    def validate_value_ranges(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Validate and fix value ranges
        
        Args:
            df: Input DataFrame
            
        Returns:
            DataFrame with validated ranges
        """
        logger.info("Validating value ranges")
        
        # Prices should be positive
        df['current_price'] = df['current_price'].clip(lower=0.01)
        df['competitor_price'] = df['competitor_price'].clip(lower=0.01)
        df['base_price'] = df['base_price'].clip(lower=0.01)
        
        # Inventory should be non-negative
        df['inventory_level'] = df['inventory_level'].clip(lower=0).astype(int)
        
        # Event counts should be non-negative
        for col in ['click_events', 'cart_additions', 'purchases', 'order_history']:
            if col in df.columns:
                df[col] = df[col].clip(lower=0).astype(int)
        
        # Percentages should be 0-100
        if 'discount_percentage' in df.columns:
            df['discount_percentage'] = df['discount_percentage'].clip(0, 100)
        
        if 'margin_percentage' in df.columns:
            df['margin_percentage'] = df['margin_percentage'].clip(0, 100)
        
        # Demand should be positive
        if 'demand' in df.columns:
            df['demand'] = df['demand'].clip(lower=0.1)
        
        logger.info("Value ranges validated")
        return df
    
    def preprocess(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Apply full preprocessing pipeline
        
        Args:
            df: Input DataFrame
            
        Returns:
            Preprocessed DataFrame
        """
        logger.info("Starting preprocessing pipeline")
        
        # Step 1: Validate
        df, report = self.validate_data(df)
        
        # Step 2: Handle missing values
        df = self.handle_missing_values(df)
        
        # Step 3: Remove duplicates
        df = self.remove_duplicates(df)
        
        # Step 4: Handle outliers
        df = self.handle_outliers(df, method='iqr')
        
        # Step 5: Validate ranges
        df = self.validate_value_ranges(df)
        
        # Step 6: Sort by timestamp
        df = df.sort_values('timestamp').reset_index(drop=True)
        
        logger.info(f"Preprocessing complete. Final shape: {df.shape}")
        return df


if __name__ == "__main__":
    # Example usage
    from src.ingestion.data_generator import SyntheticDataGenerator
    
    generator = SyntheticDataGenerator()
    pricing_df, _ = generator.generate_all(n_records=10000)
    
    preprocessor = DataPreprocessor()
    cleaned_df = preprocessor.preprocess(pricing_df)
    
    print("\n=== Preprocessing Results ===")
    print(f"Original shape: {pricing_df.shape}")
    print(f"Cleaned shape: {cleaned_df.shape}")
    print("\nCleaned data sample:")
    print(cleaned_df.head())
