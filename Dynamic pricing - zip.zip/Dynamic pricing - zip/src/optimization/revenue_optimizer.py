"""
Revenue Optimization Engine - Core pricing decision making
Integrates forecasting, elasticity, inventory, and competitor analysis
"""
import pandas as pd
import numpy as np
from typing import Dict, Any, List, Tuple
from datetime import datetime
from src.utils.logger import Logger

logger = Logger.get_logger(__name__)


class RevenueOptimizer:
    """Optimize pricing decisions for maximum revenue and profit"""
    
    def __init__(self, min_price: float = 100, max_price: float = 10000,
                 min_margin: float = 0.1, max_margin: float = 0.5):
        """
        Initialize revenue optimizer
        
        Args:
            min_price: Minimum allowed price
            max_price: Maximum allowed price
            min_margin: Minimum profit margin
            max_margin: Maximum profit margin
        """
        self.min_price = min_price
        self.max_price = max_price
        self.min_margin = min_margin
        self.max_margin = max_margin
        
        # Weighting factors for decision making
        self.weights = {
            'elasticity': 0.25,      # Price elasticity impact
            'inventory': 0.25,       # Inventory level impact
            'competitor': 0.20,      # Competitor pricing impact
            'demand': 0.15,          # Demand forecast impact
            'margin': 0.15,          # Profit margin impact
        }
        
    def calculate_stockout_risk(self, inventory: int, expected_demand: float, days: int = 7) -> float:
        """
        Calculate probability of stockout
        
        Args:
            inventory: Current inventory level
            expected_demand: Expected demand (units per day)
            days: Number of days to consider
            
        Returns:
            Stockout probability (0-1)
        """
        required_inventory = expected_demand * days
        if inventory <= 0:
            return 1.0
        
        safety_stock = 0.2 * required_inventory
        stockout_prob = max(0, min(1, (safety_stock - inventory) / (required_inventory + 1)))
        
        return stockout_prob
    
    def calculate_demand_impact(self, elasticity: float, current_price: float,
                               proposed_price: float) -> float:
        """
        Calculate demand impact of price change
        
        Args:
            elasticity: Price elasticity of demand
            current_price: Current price
            proposed_price: Proposed new price
            
        Returns:
            Demand multiplier (demand_new / demand_current)
        """
        if current_price <= 0:
            return 1.0
        
        price_change_pct = (proposed_price - current_price) / current_price
        demand_multiplier = 1 + (elasticity * price_change_pct)
        
        return max(0.1, demand_multiplier)  # Ensure positive demand
    
    def optimize_price(self, product_info: Dict[str, Any], market_conditions: Dict[str, Any],
                      forecast_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Calculate optimal price for a product
        
        Args:
            product_info: Dictionary with product details
                - product_id, base_price, category, current_price, rating
            market_conditions: Dictionary with market data
                - competitor_price, inventory_level, demand_trend, elasticity
            forecast_data: Dictionary with forecasts
                - demand_forecast, price_elasticity, trend
                
        Returns:
            Dictionary with pricing recommendation
        """
        logger.info(f"Optimizing price for product {product_info.get('product_id')}")
        
        # Extract data
        product_id = product_info.get('product_id')
        base_price = product_info.get('base_price', 100)
        current_price = product_info.get('current_price', base_price)
        category = product_info.get('category', 'General')
        
        competitor_price = market_conditions.get('competitor_price', current_price)
        inventory_level = market_conditions.get('inventory_level', 100)
        demand_trend = market_conditions.get('demand_trend', 1.0)
        elasticity = market_conditions.get('elasticity', -1.5)
        
        expected_demand = forecast_data.get('demand_forecast', 50)
        price_elasticity = forecast_data.get('price_elasticity', elasticity)
        trend = forecast_data.get('trend', 'stable')
        
        # Calculate cost (assume 40% of base price)
        unit_cost = base_price * 0.4
        
        # 1. Base price optimization
        optimal_markup = -1 / price_elasticity if price_elasticity < -0.5 else 0.25
        base_optimal_price = unit_cost * (1 + optimal_markup)
        
        # 2. Competitor analysis
        competitor_adjustment = 1.0
        if abs(current_price - competitor_price) > competitor_price * 0.05:
            if current_price > competitor_price * 1.15:
                competitor_adjustment = 0.95  # Reduce price if overpriced
            elif current_price < competitor_price * 0.85:
                competitor_adjustment = 1.05  # Increase price if underpriced
        
        competitor_adjusted_price = base_optimal_price * competitor_adjustment
        
        # 3. Inventory adjustment
        stockout_risk = self.calculate_stockout_risk(inventory_level, expected_demand)
        inventory_multiplier = 1 + (0.2 * stockout_risk) - (0.1 * (1 - stockout_risk))
        
        # If high inventory, lower price to move it
        if inventory_level > expected_demand * 5:
            inventory_multiplier *= 0.95
        elif inventory_level < expected_demand * 1.5:
            inventory_multiplier *= 1.05
        
        inventory_adjusted_price = competitor_adjusted_price * inventory_multiplier
        
        # 4. Demand trend adjustment
        demand_multiplier = 1.0
        if trend == 'trending_up':
            demand_multiplier = 1.10
        elif trend == 'trending_down':
            demand_multiplier = 0.95
        elif demand_trend > 1.2:
            demand_multiplier = 1.08
        elif demand_trend < 0.8:
            demand_multiplier = 0.92
        
        trend_adjusted_price = inventory_adjusted_price * demand_multiplier
        
        # 5. Apply constraints
        recommended_price = np.clip(trend_adjusted_price, self.min_price, self.max_price)
        
        # Ensure minimum margin
        min_price_for_margin = unit_cost / (1 - self.min_margin)
        recommended_price = max(recommended_price, min_price_for_margin)
        
        # Ensure maximum margin doesn't exceed constraint
        max_price_for_margin = unit_cost / (1 - self.max_margin)
        recommended_price = min(recommended_price, max_price_for_margin)
        
        # Calculate impact metrics
        demand_multiplier_at_new_price = self.calculate_demand_impact(elasticity, current_price, recommended_price)
        
        new_demand = expected_demand * demand_multiplier_at_new_price
        revenue_current = current_price * expected_demand
        revenue_new = recommended_price * new_demand
        revenue_lift = ((revenue_new - revenue_current) / revenue_current * 100) if revenue_current > 0 else 0
        
        profit_margin_new = (recommended_price - unit_cost) / recommended_price if recommended_price > 0 else 0
        profit_current = (current_price - unit_cost) * expected_demand
        profit_new = (recommended_price - unit_cost) * new_demand
        profit_lift = ((profit_new - profit_current) / profit_current * 100) if profit_current > 0 else 0
        
        result = {
            'product_id': product_id,
            'category': category,
            'current_price': current_price,
            'recommended_price': recommended_price,
            'price_change': recommended_price - current_price,
            'price_change_pct': ((recommended_price - current_price) / current_price * 100) if current_price > 0 else 0,
            'competitor_price': competitor_price,
            'price_vs_competitor_pct': ((recommended_price - competitor_price) / competitor_price * 100) if competitor_price > 0 else 0,
            'base_price': base_price,
            'unit_cost': unit_cost,
            'profit_margin_current': (current_price - unit_cost) / current_price if current_price > 0 else 0,
            'profit_margin_new': profit_margin_new,
            'expected_demand_current': expected_demand,
            'expected_demand_new': new_demand,
            'inventory_level': inventory_level,
            'stockout_risk': stockout_risk,
            'elasticity': elasticity,
            'revenue_current': revenue_current,
            'revenue_new': revenue_new,
            'revenue_lift_pct': revenue_lift,
            'profit_current': profit_current,
            'profit_new': profit_new,
            'profit_lift_pct': profit_lift,
            'recommendation_reason': self._generate_reason(result={
                'stockout_risk': stockout_risk,
                'demand_trend': trend,
                'competitor_price': competitor_price,
                'current_price': current_price,
                'inventory_level': inventory_level,
                'elasticity': elasticity
            }),
            'confidence_score': self._calculate_confidence(
                elasticity, competitor_price, inventory_level, expected_demand
            ),
            'timestamp': datetime.now(),
        }
        
        logger.info(f"Recommended price: ${recommended_price:.2f} (change: {result['price_change_pct']:.2f}%)")
        logger.info(f"Expected revenue lift: {revenue_lift:.2f}%")
        
        return result
    
    def _generate_reason(self, result: Dict[str, Any]) -> str:
        """Generate human-readable reason for price recommendation"""
        stockout_risk = result['stockout_risk']
        demand_trend = result['demand_trend']
        competitor_price = result['competitor_price']
        current_price = result['current_price']
        inventory_level = result['inventory_level']
        elasticity = result['elasticity']
        
        reasons = []
        
        if stockout_risk > 0.5:
            reasons.append("high stockout risk")
        elif inventory_level > 500:
            reasons.append("excess inventory")
        
        if demand_trend == 'trending_up':
            reasons.append("increasing demand")
        elif demand_trend == 'trending_down':
            reasons.append("declining demand")
        
        if abs(current_price - competitor_price) > competitor_price * 0.15:
            if current_price > competitor_price:
                reasons.append("overpriced vs competitors")
            else:
                reasons.append("underpriced vs competitors")
        
        if elasticity < -2.0:
            reasons.append("high price sensitivity")
        elif elasticity > -0.5:
            reasons.append("low price sensitivity")
        
        if not reasons:
            reasons.append("optimizing for profitability")
        
        return "; ".join(reasons)
    
    def _calculate_confidence(self, elasticity: float, competitor_price: float,
                             inventory: int, demand: float) -> float:
        """Calculate confidence score for recommendation (0-100)"""
        confidence = 50.0
        
        # Elasticity confidence
        if -2.0 < elasticity < -0.8:
            confidence += 10  # Good elasticity range
        else:
            confidence -= 5
        
        # Data quality (proxy: we have all data)
        confidence += 15
        
        # Market stability
        if 50 < inventory < 500:
            confidence += 10
        
        if demand > 20:
            confidence += 10
        
        return min(100, max(0, confidence))
    
    def batch_optimize(self, products_df: pd.DataFrame, market_df: pd.DataFrame,
                      forecast_df: pd.DataFrame) -> pd.DataFrame:
        """
        Optimize pricing for multiple products
        
        Args:
            products_df: DataFrame with product information
            market_df: DataFrame with market conditions
            forecast_df: DataFrame with forecasts
            
        Returns:
            DataFrame with pricing recommendations
        """
        logger.info(f"Batch optimizing {len(products_df)} products")
        
        recommendations = []
        
        for idx, product in products_df.iterrows():
            product_id = product['product_id']
            
            # Get market data
            market_data = market_df[market_df['product_id'] == product_id]
            if market_data.empty:
                continue
            
            market_conditions = market_data.iloc[0].to_dict()
            
            # Get forecast data
            forecast_data = forecast_df[forecast_df['product_id'] == product_id]
            if forecast_data.empty:
                forecast_data = {
                    'demand_forecast': product.get('demand', 50),
                    'price_elasticity': -1.5,
                    'trend': 'stable'
                }
            else:
                forecast_data = forecast_data.iloc[0].to_dict()
            
            # Optimize
            recommendation = self.optimize_price(
                product.to_dict(),
                market_conditions,
                forecast_data
            )
            
            recommendations.append(recommendation)
        
        results_df = pd.DataFrame(recommendations)
        logger.info(f"Generated {len(results_df)} recommendations")
        
        return results_df


if __name__ == "__main__":
    # Example usage
    optimizer = RevenueOptimizer()
    
    product_info = {
        'product_id': 1001,
        'base_price': 1000,
        'current_price': 950,
        'category': 'Electronics'
    }
    
    market_conditions = {
        'competitor_price': 1100,
        'inventory_level': 50,
        'demand_trend': 1.2,
        'elasticity': -1.8
    }
    
    forecast_data = {
        'demand_forecast': 100,
        'price_elasticity': -1.8,
        'trend': 'trending_up'
    }
    
    recommendation = optimizer.optimize_price(product_info, market_conditions, forecast_data)
    
    print("\n=== Price Optimization Result ===")
    print(f"Current Price: ${recommendation['current_price']:.2f}")
    print(f"Recommended Price: ${recommendation['recommended_price']:.2f}")
    print(f"Price Change: {recommendation['price_change_pct']:.2f}%")
    print(f"Expected Revenue Lift: {recommendation['revenue_lift_pct']:.2f}%")
    print(f"Reason: {recommendation['recommendation_reason']}")
