"""
Price elasticity analysis for understanding demand sensitivity to price changes
"""
import pandas as pd
import numpy as np
from typing import Tuple, Dict, Any
from sklearn.linear_model import LinearRegression
from scipy import stats
import matplotlib.pyplot as plt
from src.utils.logger import Logger

logger = Logger.get_logger(__name__)


class PriceElasticityAnalyzer:
    """Analyze price elasticity and demand sensitivity"""
    
    def __init__(self):
        """Initialize elasticity analyzer"""
        self.elasticity_models = {}
        self.elasticity_by_category = {}
        self.elasticity_by_segment = {}
        
    def calculate_elasticity(self, df: pd.DataFrame, price_col: str = 'current_price',
                            demand_col: str = 'demand', groupby_col: str = None) -> Dict[str, float]:
        """
        Calculate price elasticity of demand
        Elasticity = % change in demand / % change in price
        
        Args:
            df: DataFrame with price and demand data
            price_col: Column name for price
            demand_col: Column name for demand
            groupby_col: Column to group by (e.g., product_id, category)
            
        Returns:
            Dictionary of elasticity values
        """
        logger.info("Calculating price elasticity")
        
        elasticity = {}
        
        if groupby_col is None:
            # Overall elasticity
            X = np.log(df[price_col].clip(lower=0.01)).values.reshape(-1, 1)
            y = np.log(df[demand_col].clip(lower=0.1))
            
            # Fit log-log model for elasticity
            model = LinearRegression()
            model.fit(X, y)
            
            elasticity['overall'] = float(model.coef_[0])
            elasticity['r_squared'] = float(model.score(X, y))
            
            logger.info(f"Overall elasticity: {elasticity['overall']:.4f}")
        else:
            # Elasticity by group
            for group_val in df[groupby_col].unique():
                group_data = df[df[groupby_col] == group_val]
                
                if len(group_data) < 10:  # Need minimum data points
                    continue
                
                X = np.log(group_data[price_col].clip(lower=0.01)).values.reshape(-1, 1)
                y = np.log(group_data[demand_col].clip(lower=0.1))
                
                model = LinearRegression()
                model.fit(X, y)
                
                elasticity[group_val] = {
                    'elasticity': float(model.coef_[0]),
                    'r_squared': float(model.score(X, y)),
                    'intercept': float(model.intercept_),
                }
            
            logger.info(f"Calculated elasticity for {len(elasticity)} groups")
        
        return elasticity
    
    def estimate_optimal_price(self, base_price: float, elasticity: float,
                              cost: float, target_margin: float = 0.25) -> float:
        """
        Estimate optimal price given elasticity and costs
        Using markup formula with elasticity
        
        Args:
            base_price: Base product price
            elasticity: Price elasticity of demand
            cost: Unit cost
            target_margin: Target profit margin
            
        Returns:
            Optimal price
        """
        if elasticity >= -1:  # Inelastic
            logger.warning("Demand is inelastic, price increase may maximize revenue")
            optimal_price = cost / (1 - target_margin)
        else:
            # Lerner index: (P - MC) / P = -1/E
            # Optimal markup = -1 / elasticity
            markup = -1 / elasticity
            optimal_price = cost * (1 + markup * target_margin)
        
        return optimal_price
    
    def price_sensitivity_analysis(self, df: pd.DataFrame, price_col: str = 'current_price',
                                  demand_col: str = 'demand',
                                  price_range: Tuple[float, float] = None) -> pd.DataFrame:
        """
        Analyze demand at different price points
        
        Args:
            df: DataFrame with price and demand data
            price_col: Price column
            demand_col: Demand column
            price_range: Tuple of (min_price, max_price) for analysis
            
        Returns:
            DataFrame with price sensitivity analysis
        """
        logger.info("Performing price sensitivity analysis")
        
        if price_range is None:
            min_price = df[price_col].quantile(0.1)
            max_price = df[price_col].quantile(0.9)
            price_range = (min_price, max_price)
        
        # Create price bins
        df['price_bin'] = pd.cut(df[price_col], bins=10)
        
        sensitivity = df.groupby('price_bin', observed=True).agg({
            price_col: 'mean',
            demand_col: ['mean', 'std'],
            'purchases': 'sum',
            'revenue': 'sum',
        }).reset_index(drop=True)
        
        sensitivity.columns = ['avg_price', 'avg_demand', 'demand_std', 'total_purchases', 'total_revenue']
        
        # Calculate elasticity for each segment
        sensitivity['elasticity'] = 0.0
        for i in range(1, len(sensitivity)):
            price_change = (sensitivity.loc[i, 'avg_price'] - sensitivity.loc[i-1, 'avg_price']) / sensitivity.loc[i-1, 'avg_price']
            demand_change = (sensitivity.loc[i, 'avg_demand'] - sensitivity.loc[i-1, 'avg_demand']) / sensitivity.loc[i-1, 'avg_demand']
            
            if price_change != 0:
                sensitivity.loc[i, 'elasticity'] = demand_change / price_change
        
        logger.info(f"Sensitivity analysis across {len(sensitivity)} price points")
        return sensitivity
    
    def revenue_maximization_curve(self, df: pd.DataFrame, price_col: str = 'current_price',
                                  demand_col: str = 'demand', n_points: int = 50) -> pd.DataFrame:
        """
        Generate revenue maximization curve across price points
        
        Args:
            df: DataFrame with price and demand data
            price_col: Price column
            demand_col: Demand column
            n_points: Number of price points to analyze
            
        Returns:
            DataFrame with revenue optimization curve
        """
        logger.info("Generating revenue maximization curve")
        
        min_price = df[price_col].min()
        max_price = df[price_col].max()
        
        price_points = np.linspace(min_price, max_price, n_points)
        
        results = []
        for price in price_points:
            # Find data near this price point
            tolerance = (max_price - min_price) / (2 * n_points)
            nearby_data = df[(df[price_col] >= price - tolerance) & (df[price_col] <= price + tolerance)]
            
            if len(nearby_data) == 0:
                continue
            
            avg_demand = nearby_data[demand_col].mean()
            avg_revenue_per_unit = nearby_data['revenue'].mean() / nearby_data['purchases'].clip(lower=1).mean()
            total_revenue = price * avg_demand
            
            results.append({
                'price': price,
                'expected_demand': avg_demand,
                'revenue_per_unit': avg_revenue_per_unit,
                'total_revenue': total_revenue,
            })
        
        curve_df = pd.DataFrame(results)
        
        if len(curve_df) > 0:
            optimal_idx = curve_df['total_revenue'].idxmax()
            logger.info(f"Optimal price point: ${curve_df.loc[optimal_idx, 'price']:.2f}")
        
        return curve_df
    
    def discount_impact_analysis(self, df: pd.DataFrame, discount_col: str = 'discount_percentage',
                                demand_col: str = 'demand', revenue_col: str = 'revenue') -> pd.DataFrame:
        """
        Analyze impact of discounts on demand and revenue
        
        Args:
            df: DataFrame with discount and performance data
            discount_col: Discount column
            demand_col: Demand column
            revenue_col: Revenue column
            
        Returns:
            DataFrame with discount impact analysis
        """
        logger.info("Analyzing discount impact")
        
        # Create discount bins
        df['discount_bin'] = pd.cut(df[discount_col], bins=5)
        
        impact = df.groupby('discount_bin', observed=True).agg({
            discount_col: 'mean',
            demand_col: 'mean',
            revenue_col: 'mean',
            'purchases': 'mean',
        }).reset_index(drop=True)
        
        impact.columns = ['avg_discount', 'avg_demand', 'avg_revenue', 'avg_purchases']
        
        # Calculate ROI of discount
        impact['discount_roi'] = (impact['avg_demand'] / (100 - impact['avg_discount']).clip(lower=0.1)) - 1
        
        logger.info(f"Analyzed discount impact across {len(impact)} discount bins")
        return impact
    
    def segment_elasticity_analysis(self, df: pd.DataFrame, segment_col: str = 'customer_segment',
                                   price_col: str = 'current_price',
                                   demand_col: str = 'demand') -> Dict[str, Dict[str, float]]:
        """
        Analyze elasticity by customer segment
        
        Args:
            df: DataFrame with segment and price/demand data
            segment_col: Customer segment column
            price_col: Price column
            demand_col: Demand column
            
        Returns:
            Dictionary with elasticity by segment
        """
        logger.info("Analyzing elasticity by customer segment")
        
        segment_elasticity = {}
        
        for segment in df[segment_col].unique():
            segment_data = df[df[segment_col] == segment]
            
            elasticity = self.calculate_elasticity(segment_data, price_col, demand_col)
            segment_elasticity[segment] = elasticity
        
        logger.info(f"Calculated elasticity for {len(segment_elasticity)} segments")
        return segment_elasticity
    
    def price_recommendation(self, product_data: pd.Series, elasticity: float, cost: float,
                            competitor_price: float, inventory_level: int,
                            demand_forecast: float) -> Dict[str, Any]:
        """
        Generate comprehensive price recommendation
        
        Args:
            product_data: Series with product information
            elasticity: Price elasticity
            cost: Unit cost
            competitor_price: Competitor price
            inventory_level: Current inventory
            demand_forecast: Forecasted demand
            
        Returns:
            Dictionary with price recommendation and reasoning
        """
        logger.info("Generating price recommendation")
        
        current_price = product_data.get('current_price', 100)
        base_price = product_data.get('base_price', 100)
        
        recommendation = {
            'current_price': current_price,
            'elasticity': elasticity,
        }
        
        # Calculate optimal price
        optimal_price = self.estimate_optimal_price(base_price, elasticity, cost * 0.4)
        recommendation['optimal_price'] = optimal_price
        
        # Adjust for inventory
        if inventory_level < demand_forecast:
            # Low inventory - increase price
            recommended_price = optimal_price * 1.1
            recommendation['reason'] = 'Low inventory - increase price'
        elif inventory_level > demand_forecast * 3:
            # High inventory - decrease price
            recommended_price = optimal_price * 0.9
            recommendation['reason'] = 'High inventory - decrease price'
        else:
            # Balanced inventory
            recommended_price = optimal_price
            recommendation['reason'] = 'Balanced inventory'
        
        # Consider competitor pricing
        if recommended_price > competitor_price * 1.15:
            recommended_price = competitor_price * 1.10
            recommendation['reason'] += ' (adjusted for competition)'
        elif recommended_price < competitor_price * 0.85:
            recommended_price = competitor_price * 0.90
            recommendation['reason'] += ' (competitive positioning)'
        
        recommendation['recommended_price'] = recommended_price
        recommendation['price_change_pct'] = ((recommended_price - current_price) / current_price) * 100
        
        return recommendation


if __name__ == "__main__":
    from src.ingestion.data_generator import SyntheticDataGenerator
    from src.preprocessing.data_preprocessor import DataPreprocessor
    
    # Generate data
    generator = SyntheticDataGenerator()
    pricing_df, _ = generator.generate_all(n_records=5000)
    
    preprocessor = DataPreprocessor()
    cleaned_df = preprocessor.preprocess(pricing_df)
    
    # Analyze elasticity
    analyzer = PriceElasticityAnalyzer()
    
    # Overall elasticity
    elasticity = analyzer.calculate_elasticity(cleaned_df)
    print("\n=== Price Elasticity Analysis ===")
    print(f"Overall elasticity: {elasticity}")
    
    # By category
    category_elasticity = analyzer.calculate_elasticity(cleaned_df, groupby_col='category')
    print("\nElasticity by category:")
    for cat, elast in category_elasticity.items():
        print(f"{cat}: {elast}")
    
    # Sensitivity analysis
    sensitivity = analyzer.price_sensitivity_analysis(cleaned_df)
    print("\nPrice sensitivity analysis:")
    print(sensitivity.head())
