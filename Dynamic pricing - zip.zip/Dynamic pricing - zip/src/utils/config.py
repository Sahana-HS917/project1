"""
Configuration management for Dynamic Pricing Engine
"""
import os
from pathlib import Path
from typing import Optional
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings"""
    
    # Project paths
    PROJECT_ROOT: Path = Path(__file__).parent.parent.parent
    DATA_DIR: Path = PROJECT_ROOT / "data"
    MODELS_DIR: Path = PROJECT_ROOT / "models"
    REPORTS_DIR: Path = PROJECT_ROOT / "reports"
    
    # Database
    DATABASE_URL: str = "sqlite:///./dynamic_pricing.db"
    
    # Redis
    REDIS_HOST: str = "localhost"
    REDIS_PORT: int = 6379
    REDIS_DB: int = 0
    REDIS_CACHE_EXPIRY: int = 3600  # 1 hour
    
    # Kafka
    KAFKA_BOOTSTRAP_SERVERS: list = ["localhost:9092"]
    KAFKA_TOPIC_PRICING: str = "pricing-updates"
    KAFKA_TOPIC_INVENTORY: str = "inventory-updates"
    KAFKA_TOPIC_COMPETITOR: str = "competitor-updates"
    KAFKA_TOPIC_EVENTS: str = "customer-events"
    
    # API Settings
    API_HOST: str = "0.0.0.0"
    API_PORT: int = 8000
    API_TITLE: str = "Dynamic Pricing Engine API"
    API_VERSION: str = "1.0.0"
    
    # Model Settings
    PRICE_MIN_THRESHOLD: float = 100.0
    PRICE_MAX_THRESHOLD: float = 10000.0
    FORECAST_DAYS: int = 30
    LOOKBACK_DAYS: int = 90
    
    # Feature Engineering
    SCALING_METHOD: str = "standard"  # standard or robust
    FEATURE_SELECTION_METHOD: str = "importance"  # importance or correlation
    
    # Model Training
    TEST_SIZE: float = 0.2
    VALIDATION_SIZE: float = 0.1
    RANDOM_STATE: int = 42
    N_TRIALS_OPTUNA: int = 100
    
    # Monitoring
    PROMETHEUS_PORT: int = 8001
    LOG_LEVEL: str = "INFO"
    
    # Performance
    BATCH_SIZE: int = 1000
    MAX_WORKERS: int = 4
    REQUEST_TIMEOUT: int = 30
    
    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()
