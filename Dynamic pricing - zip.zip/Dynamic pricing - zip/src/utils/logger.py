"""
Logging configuration for Dynamic Pricing Engine
"""
import logging
import logging.handlers
from pathlib import Path
from datetime import datetime
from src.utils.config import settings


def setup_logging(module_name: str, level: str = None) -> logging.Logger:
    """
    Setup logging for a module
    
    Args:
        module_name: Name of the module
        level: Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        
    Returns:
        Configured logger instance
    """
    if level is None:
        level = settings.LOG_LEVEL
    
    # Create logger
    logger = logging.getLogger(module_name)
    logger.setLevel(getattr(logging, level))
    
    # Create formatters
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(getattr(logging, level))
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # File handler
    log_dir = Path("logs")
    log_dir.mkdir(exist_ok=True)
    log_file = log_dir / f"{module_name}_{datetime.now().strftime('%Y%m%d')}.log"
    
    file_handler = logging.handlers.RotatingFileHandler(
        log_file,
        maxBytes=10485760,  # 10MB
        backupCount=10
    )
    file_handler.setLevel(getattr(logging, level))
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    
    return logger


class Logger:
    """Logger wrapper for consistent logging"""
    
    @staticmethod
    def get_logger(name: str) -> logging.Logger:
        """Get a configured logger"""
        return setup_logging(name)
