"""
SHAP Explainability Module for model interpretability
Provides global and local feature importance explanations
"""
import pandas as pd
import numpy as np
from typing import Dict, Any, List, Tuple
import matplotlib.pyplot as plt
import shap
import joblib
from src.utils.logger import Logger

logger = Logger.get_logger(__name__)


class ModelExplainer:
    """Explain model predictions using SHAP"""
    
    def __init__(self, model, feature_names: List[str] = None):
        """
        Initialize explainer
        
        Args:
            model: Trained model to explain
            feature_names: List of feature names
        """
        self.model = model
        self.feature_names = feature_names or []
        self.explainer = None
        self.shap_values = None
        
    def initialize_explainer(self, background_data: pd.DataFrame, method: str = 'tree') -> None:
        """
        Initialize SHAP explainer
        
        Args:
            background_data: Background data for SHAP (sample of training data)
            method: Explainer method ('tree', 'kernel', 'linear')
        """
        logger.info(f"Initializing {method} SHAP explainer")
        
        try:
            if method == 'tree':
                self.explainer = shap.TreeExplainer(self.model)
            elif method == 'kernel':
                self.explainer = shap.KernelExplainer(self.model.predict, background_data)
            elif method == 'linear':
                self.explainer = shap.LinearExplainer(self.model, background_data)
            else:
                raise ValueError(f"Unknown explainer method: {method}")
            
            logger.info("Explainer initialized successfully")
        
        except Exception as e:
            logger.error(f"Error initializing explainer: {str(e)}")
            raise
    
    def calculate_shap_values(self, data: pd.DataFrame) -> np.ndarray:
        """
        Calculate SHAP values for data
        
        Args:
            data: Input data
            
        Returns:
            SHAP values array
        """
        logger.info(f"Calculating SHAP values for {len(data)} samples")
        
        if self.explainer is None:
            raise ValueError("Explainer not initialized. Call initialize_explainer first.")
        
        self.shap_values = self.explainer.shap_values(data)
        
        logger.info("SHAP values calculated")
        return self.shap_values
    
    def get_global_feature_importance(self) -> pd.DataFrame:
        """
        Get global feature importance from SHAP values
        
        Returns:
            DataFrame with global importance scores
        """
        if self.shap_values is None:
            raise ValueError("SHAP values not calculated. Call calculate_shap_values first.")
        
        logger.info("Computing global feature importance")
        
        # Calculate mean absolute SHAP values for each feature
        if isinstance(self.shap_values, list):  # For multi-output models
            shap_values = self.shap_values[0]
        else:
            shap_values = self.shap_values
        
        importance = np.abs(shap_values).mean(axis=0)
        
        importance_df = pd.DataFrame({
            'feature': self.feature_names if self.feature_names else [f'Feature_{i}' for i in range(len(importance))],
            'importance': importance,
        }).sort_values('importance', ascending=False)
        
        logger.info("Global importance computed")
        return importance_df
    
    def explain_prediction(self, instance: pd.Series, instance_idx: int = 0) -> Dict[str, Any]:
        """
        Explain individual prediction
        
        Args:
            instance: Single data point to explain
            instance_idx: Index in SHAP values
            
        Returns:
            Dictionary with explanation
        """
        if self.shap_values is None:
            raise ValueError("SHAP values not calculated")
        
        logger.info(f"Explaining prediction {instance_idx}")
        
        if isinstance(self.shap_values, list):
            shap_vals = self.shap_values[0][instance_idx]
        else:
            shap_vals = self.shap_values[instance_idx]
        
        # Sort features by absolute SHAP value
        feature_importance_idx = np.argsort(np.abs(shap_vals))[::-1]
        
        explanation = {
            'prediction': self.model.predict(instance.values.reshape(1, -1))[0],
            'top_positive_features': [],
            'top_negative_features': [],
        }
        
        # Get top contributing features
        for idx in feature_importance_idx[:5]:
            feature_name = self.feature_names[idx] if self.feature_names else f'Feature_{idx}'
            shap_value = shap_vals[idx]
            feature_value = instance.iloc[idx]
            
            if shap_value > 0:
                explanation['top_positive_features'].append({
                    'feature': feature_name,
                    'value': feature_value,
                    'contribution': shap_value,
                })
            else:
                explanation['top_negative_features'].append({
                    'feature': feature_name,
                    'value': feature_value,
                    'contribution': shap_value,
                })
        
        return explanation
    
    def plot_summary(self, output_path: str = None) -> None:
        """
        Create SHAP summary plot
        
        Args:
            output_path: Path to save plot
        """
        logger.info("Generating SHAP summary plot")
        
        if self.shap_values is None:
            raise ValueError("SHAP values not calculated")
        
        try:
            plt.figure()
            shap.summary_plot(self.shap_values, plot_type="bar", show=False)
            
            if output_path:
                plt.savefig(output_path)
                logger.info(f"Summary plot saved to {output_path}")
            
            plt.close()
        
        except Exception as e:
            logger.error(f"Error creating summary plot: {str(e)}")
    
    def plot_waterfall(self, instance_idx: int = 0, output_path: str = None) -> None:
        """
        Create SHAP waterfall plot for instance
        
        Args:
            instance_idx: Index of instance to explain
            output_path: Path to save plot
        """
        logger.info(f"Generating SHAP waterfall plot for instance {instance_idx}")
        
        if self.shap_values is None:
            raise ValueError("SHAP values not calculated")
        
        try:
            if isinstance(self.shap_values, list):
                shap_vals = self.shap_values[0][instance_idx]
            else:
                shap_vals = self.shap_values[instance_idx]
            
            plt.figure()
            shap.plots._waterfall.waterfall_legacy(
                self.explainer.expected_value,
                shap_vals,
                show=False
            )
            
            if output_path:
                plt.savefig(output_path)
                logger.info(f"Waterfall plot saved to {output_path}")
            
            plt.close()
        
        except Exception as e:
            logger.error(f"Error creating waterfall plot: {str(e)}")
    
    def get_price_factors(self, price_prediction: float, features: Dict[str, float],
                         instance_idx: int = 0) -> Dict[str, Any]:
        """
        Extract top factors influencing price recommendation
        
        Args:
            price_prediction: Predicted price
            features: Dictionary of feature values
            instance_idx: Index in SHAP values
            
        Returns:
            Dictionary with top price factors
        """
        logger.info("Extracting price influencing factors")
        
        if self.shap_values is None:
            raise ValueError("SHAP values not calculated")
        
        if isinstance(self.shap_values, list):
            shap_vals = self.shap_values[0][instance_idx]
        else:
            shap_vals = self.shap_values[instance_idx]
        
        # Get top contributing features
        top_indices = np.argsort(np.abs(shap_vals))[::-1][:5]
        
        factors = {
            'predicted_price': price_prediction,
            'top_factors': []
        }
        
        for idx in top_indices:
            feature_name = self.feature_names[idx] if self.feature_names else f'Feature_{idx}'
            shap_value = float(shap_vals[idx])
            
            factors['top_factors'].append({
                'factor': feature_name,
                'contribution': shap_value,
                'impact': 'increases' if shap_value > 0 else 'decreases',
                'magnitude': abs(shap_value)
            })
        
        logger.info(f"Extracted {len(factors['top_factors'])} price factors")
        return factors


class PricingExplainer:
    """Specific explainer for pricing decisions"""
    
    def __init__(self, model_explainer: ModelExplainer):
        """
        Initialize pricing explainer
        
        Args:
            model_explainer: ModelExplainer instance
        """
        self.explainer = model_explainer
        
    def explain_price_change(self, old_price: float, new_price: float,
                            reason: str, factors: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate human-readable explanation for price change
        
        Args:
            old_price: Current price
            new_price: Recommended price
            reason: Reason for change
            factors: Top factors from SHAP
            
        Returns:
            Detailed explanation
        """
        logger.info(f"Generating price change explanation: ${old_price} -> ${new_price}")
        
        price_change_pct = ((new_price - old_price) / old_price * 100) if old_price > 0 else 0
        
        explanation = {
            'old_price': old_price,
            'new_price': new_price,
            'price_change': new_price - old_price,
            'price_change_pct': price_change_pct,
            'reason': reason,
            'summary': self._generate_summary(old_price, new_price, reason, factors),
            'top_factors': factors.get('top_factors', []),
        }
        
        return explanation
    
    def _generate_summary(self, old_price: float, new_price: float,
                         reason: str, factors: Dict[str, Any]) -> str:
        """Generate human-readable summary"""
        price_change_pct = ((new_price - old_price) / old_price * 100) if old_price > 0 else 0
        direction = "increase" if price_change_pct > 0 else "decrease"
        
        summary = f"Price recommendation to {direction} by {abs(price_change_pct):.1f}% "
        summary += f"(${old_price:.2f} → ${new_price:.2f}). "
        summary += f"Primary reason: {reason}. "
        
        if factors.get('top_factors'):
            top_factor = factors['top_factors'][0]
            summary += f"Key driver: {top_factor['factor']} ({top_factor['impact']} pricing)."
        
        return summary


if __name__ == "__main__":
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.datasets import make_regression
    
    # Create dummy data and model
    X, y = make_regression(n_samples=100, n_features=10, random_state=42)
    feature_names = [f'Feature_{i}' for i in range(10)]
    
    model = RandomForestRegressor(n_estimators=10, random_state=42)
    model.fit(X, y)
    
    # Create explainer
    X_df = pd.DataFrame(X, columns=feature_names)
    explainer = ModelExplainer(model, feature_names)
    explainer.initialize_explainer(X_df[:20])  # Use subset for background
    explainer.calculate_shap_values(X_df)
    
    # Get global importance
    importance = explainer.get_global_feature_importance()
    print("\n=== Global Feature Importance ===")
    print(importance)
    
    # Explain single prediction
    explanation = explainer.explain_prediction(X_df.iloc[0])
    print("\n=== Prediction Explanation ===")
    print(explanation)
