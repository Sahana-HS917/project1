"""
Advanced feature engineering for pricing optimization
Implements time, demand, pricing, inventory, and customer features
"""
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, RobustScaler, LabelEncoder
from typing import Tuple, Dict, Any, List
from src.utils.logger import Logger

logger = Logger.get_logger(__name__)


class FeatureEngineer:
    """Create advanced pricing features"""
    
    def __init__(self, scaling_method: str = 'standard'):
        """
        Initialize feature engineer
        
        Args:
            scaling_method: 'standard' or 'robust'
        """
        self.scaling_method = scaling_method
        self.scaler = StandardScaler() if scaling_method == 'standard' else RobustScaler()
        self.label_encoders = {}
        self.feature_names = []
        
    def create_temporal_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Create time-based features
        
        Args:
            df: Input DataFrame with timestamp column
            
        Returns:
            DataFrame with temporal features
        """
        logger.info("Creating temporal features")
        
        if 'timestamp' not in df.columns:
            raise ValueError("DataFrame must contain 'timestamp' column")
        
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        
        # Extract time components
        df['hour'] = df['timestamp'].dt.hour
        df['day_of_week'] = df['timestamp'].dt.dayofweek
        df['day_of_month'] = df['timestamp'].dt.day
        df['month'] = df['timestamp'].dt.month
        df['quarter'] = df['timestamp'].dt.quarter
        df['week_of_year'] = df['timestamp'].dt.isocalendar().week
        
        # Cyclical encoding for hour (0-23 -> sine/cosine)
        df['hour_sin'] = np.sin(2 * np.pi * df['hour'] / 24)
        df['hour_cos'] = np.cos(2 * np.pi * df['hour'] / 24)
        
        # Cyclical encoding for day of week
        df['dow_sin'] = np.sin(2 * np.pi * df['day_of_week'] / 7)
        df['dow_cos'] = np.cos(2 * np.pi * df['day_of_week'] / 7)
        
        # Cyclical encoding for month
        df['month_sin'] = np.sin(2 * np.pi * df['month'] / 12)
        df['month_cos'] = np.cos(2 * np.pi * df['month'] / 12)
        
        # Holiday flags
        df['is_holiday'] = df['month'].isin([1, 12]).astype(int)  # Jan, Dec
        df['is_weekend'] = df['day_of_week'].isin([5, 6]).astype(int)
        
        logger.info(f"Created {len([c for c in df.columns if c.endswith(('_sin', '_cos'))])} cyclical features")
        return df
    
    def create_demand_features(self, df: pd.DataFrame, lookback_periods: List[int] = [7, 14, 30]) -> pd.DataFrame:
        """
        Create demand-related features
        
        Args:
            df: Input DataFrame
            lookback_periods: Periods for rolling calculations (days)
            
        Returns:
            DataFrame with demand features
        """
        logger.info("Creating demand features")
        
        # Ensure timestamp is sorted
        df = df.sort_values('timestamp').reset_index(drop=True)
        
        # Group by product for rolling calculations
        for period in lookback_periods:
            # Use groupby with rolling
            df[f'sales_ma_{period}'] = (df.groupby('product_id')['purchases']
                                        .rolling(window=period, min_periods=1)
                                        .mean()
                                        .reset_index(level=0, drop=True))
            
            df[f'revenue_ma_{period}'] = (df.groupby('product_id')['revenue']
                                          .rolling(window=period, min_periods=1)
                                          .mean()
                                          .reset_index(level=0, drop=True))
            
            df[f'demand_ma_{period}'] = (df.groupby('product_id')['demand']
                                         .rolling(window=period, min_periods=1)
                                         .mean()
                                         .reset_index(level=0, drop=True))
        
        # Sales velocity (change in sales)
        df['sales_velocity'] = df.groupby('product_id')['purchases'].diff().fillna(0)
        
        # Cart conversion rate
        df['cart_conversion_rate'] = (df['purchases'] / (df['cart_additions'].clip(lower=1))).clip(0, 1)
        
        # Click-to-purchase conversion
        df['click_conversion_rate'] = (df['purchases'] / (df['click_events'].clip(lower=1))).clip(0, 1)
        
        # Customer acquisition from seasonality
        df['seasonal_multiplier'] = df['demand'] / (df['demand_ma_30'].clip(lower=0.1))
        
        logger.info("Created demand features with rolling averages")
        return df
    
    def create_pricing_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Create pricing-related features
        
        Args:
            df: Input DataFrame
            
        Returns:
            DataFrame with pricing features
        """
        logger.info("Creating pricing features")
        
        # Price differential
        df['price_diff_competitor'] = df['current_price'] - df['competitor_price']
        df['price_diff_base'] = df['current_price'] - df['base_price']
        df['price_diff_pct'] = (df['price_diff_competitor'] / df['competitor_price'].clip(lower=0.01)) * 100
        
        # Discounting
        df['discount_level'] = df['current_price'] / df['base_price'].clip(lower=0.01)
        
        # Price elasticity (approximate)
        df['elasticity_score'] = df['price_elasticity'].fillna(-1.5)
        
        # Margin analysis
        if 'margin_percentage' not in df.columns:
            df['margin_percentage'] = ((df['revenue'] - df['purchases'] * df['base_price'] * 0.4) / 
                                       df['revenue'].clip(lower=0.01) * 100)
        
        # Competitive positioning
        df['is_underpriced'] = (df['current_price'] < df['competitor_price']).astype(int)
        df['is_overpriced'] = (df['current_price'] > df['competitor_price'] * 1.1).astype(int)
        
        # Price momentum
        df['price_momentum'] = df.groupby('product_id')['current_price'].diff().fillna(0)
        
        logger.info("Created pricing features")
        return df
    
    def create_inventory_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Create inventory-related features
        
        Args:
            df: Input DataFrame
            
        Returns:
            DataFrame with inventory features
        """
        logger.info("Creating inventory features")
        
        # Inventory-to-demand ratio
        df['inventory_to_demand'] = (df['inventory_level'] / df['demand'].clip(lower=0.1)).fillna(0)
        
        # Days of inventory
        df['days_of_inventory'] = (df['inventory_level'] / df['purchases'].clip(lower=1)).clip(0, 365)
        
        # Stockout risk
        df['stockout_risk'] = (df['purchases'] > df['inventory_level'] * 0.1).astype(int)
        
        # Inventory turnover rate (proxy)
        df['turnover_rate'] = df['purchases'] / df['inventory_level'].clip(lower=1)
        
        # Low inventory flag
        df['low_inventory'] = (df['inventory_level'] < df['purchases'] * 2).astype(int)
        
        logger.info("Created inventory features")
        return df
    
    def create_customer_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Create customer behavior features
        
        Args:
            df: Input DataFrame
            
        Returns:
            DataFrame with customer features
        """
        logger.info("Creating customer features")
        
        # Customer segment influence
        if 'customer_segment' in df.columns:
            segment_map = {'budget': 1, 'standard': 2, 'premium': 3, 'vip': 4}
            df['segment_score'] = df['customer_segment'].map(segment_map).fillna(2)
        
        # Purchase frequency (historical)
        if 'order_history' in df.columns:
            df['repeat_customer_score'] = df['order_history'] / (df['order_history'].max() + 1)
        
        # Product popularity (rating-based)
        if 'product_rating' in df.columns:
            df['rating_normalized'] = df['product_rating'] / 5.0
            
            # Review count popularity
            if 'review_count' in df.columns:
                df['review_popularity'] = df['review_count'] / (df['review_count'].max() + 1)
        
        # Engagement score
        df['engagement_score'] = (
            (df['click_events'] / df['click_events'].max()) +
            (df['cart_additions'] / df['cart_additions'].max()) +
            (df['purchases'] / df['purchases'].max())
        ) / 3
        
        logger.info("Created customer features")
        return df
    
    def encode_categorical_features(self, df: pd.DataFrame, fit: bool = True) -> pd.DataFrame:
        """
        Encode categorical variables
        
        Args:
            df: Input DataFrame
            fit: Whether to fit encoders (True for training, False for inference)
            
        Returns:
            DataFrame with encoded features
        """
        logger.info("Encoding categorical features")
        
        categorical_cols = ['category', 'customer_segment', 'seasonal_factor']
        
        for col in categorical_cols:
            if col in df.columns:
                if fit:
                    self.label_encoders[col] = LabelEncoder()
                    df[f'{col}_encoded'] = self.label_encoders[col].fit_transform(df[col].astype(str))
                else:
                    if col in self.label_encoders:
                        df[f'{col}_encoded'] = self.label_encoders[col].transform(df[col].astype(str))
        
        logger.info(f"Encoded {len(self.label_encoders)} categorical columns")
        return df
    
    def scale_features(self, df: pd.DataFrame, feature_cols: List[str] = None, fit: bool = True) -> pd.DataFrame:
        """
        Scale numerical features
        
        Args:
            df: Input DataFrame
            feature_cols: Columns to scale
            fit: Whether to fit scaler
            
        Returns:
            DataFrame with scaled features
        """
        if feature_cols is None:
            feature_cols = df.select_dtypes(include=[np.number]).columns
            # Exclude binary features
            feature_cols = [col for col in feature_cols if df[col].nunique() > 2]
        
        logger.info(f"Scaling {len(feature_cols)} features using {self.scaling_method}")
        
        if fit:
            df[feature_cols] = self.scaler.fit_transform(df[feature_cols])
        else:
            df[feature_cols] = self.scaler.transform(df[feature_cols])
        
        return df
    
    def engineer_features(self, df: pd.DataFrame, fit: bool = True) -> pd.DataFrame:
        """
        Apply full feature engineering pipeline
        
        Args:
            df: Input DataFrame
            fit: Whether to fit transformers
            
        Returns:
            DataFrame with engineered features
        """
        logger.info("Starting feature engineering pipeline")
        
        # Create all features
        df = self.create_temporal_features(df)
        df = self.create_demand_features(df)
        df = self.create_pricing_features(df)
        df = self.create_inventory_features(df)
        df = self.create_customer_features(df)
        df = self.encode_categorical_features(df, fit=fit)
        
        # Get numeric features for scaling
        numeric_features = df.select_dtypes(include=[np.number]).columns.tolist()
        self.feature_names = numeric_features
        
        # Don't scale encoded features and binary flags
        features_to_scale = [f for f in numeric_features if not any(
            x in f for x in ['_encoded', '_sin', '_cos', 'flag', 'is_', 'low_', 'stockout_']
        )]
        
        # Scale features
        if fit:
            df = self.scale_features(df, feature_cols=features_to_scale, fit=True)
        
        logger.info(f"Feature engineering complete. Shape: {df.shape}")
        logger.info(f"Created {len(self.feature_names)} numerical features")
        
        return df


if __name__ == "__main__":
    from src.ingestion.data_generator import SyntheticDataGenerator
    from src.preprocessing.data_preprocessor import DataPreprocessor
    
    # Generate and preprocess data
    generator = SyntheticDataGenerator()
    pricing_df, _ = generator.generate_all(n_records=10000)
    
    preprocessor = DataPreprocessor()
    cleaned_df = preprocessor.preprocess(pricing_df)
    
    # Engineer features
    engineer = FeatureEngineer(scaling_method='standard')
    feature_df = engineer.engineer_features(cleaned_df)
    
    print("\n=== Feature Engineering Results ===")
    print(f"Input shape: {cleaned_df.shape}")
    print(f"Output shape: {feature_df.shape}")
    print(f"\nFeature count: {len(engineer.feature_names)}")
    print("\nSample features:")
    print(feature_df.head())
