"""
Streamlit Dashboard for Dynamic Pricing Engine
Modern, interactive UI for pricing analytics and decision making
"""
import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import os

# Page configuration
st.set_page_config(
    page_title="Dynamic Pricing Engine",
    page_icon="💰",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom styling
st.markdown("""
    <style>
    .metric-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 20px;
        border-radius: 10px;
        color: white;
    }
    .price-up {
        color: #00ff00;
        font-weight: bold;
    }
    .price-down {
        color: #ff0000;
        font-weight: bold;
    }
    </style>
""", unsafe_allow_html=True)


def generate_sample_data():
    """Generate sample data for demonstration"""
    dates = pd.date_range(start='2024-01-01', periods=90, freq='D')
    
    data = {
        'date': dates,
        'product_id': np.random.randint(1001, 1010, 90),
        'product_name': np.random.choice(['Laptop', 'Phone', 'Tablet', 'Headphones'], 90),
        'current_price': np.random.uniform(500, 1500, 90),
        'recommended_price': np.random.uniform(500, 1500, 90),
        'competitor_price': np.random.uniform(500, 1500, 90),
        'inventory': np.random.randint(10, 200, 90),
        'demand': np.random.randint(20, 200, 90),
        'revenue': np.random.uniform(10000, 50000, 90),
        'price_elasticity': np.random.uniform(-2.5, -1.0, 90),
    }
    
    return pd.DataFrame(data)


def main():
    """Main app"""
    
    # Sidebar navigation
    with st.sidebar:
        st.title("📊 Navigation")
        page = st.radio(
            "Select Page:",
            ["Dashboard", "Price Analytics", "Demand Forecasting",
             "Competitor Monitor", "Inventory", "SHAP Explainability",
             "Real-Time Feed", "Settings"]
        )
    
    # Load sample data
    df = generate_sample_data()
    
    # Dashboard Page
    if page == "Dashboard":
        dashboard_page(df)
    
    # Price Analytics
    elif page == "Price Analytics":
        price_analytics_page(df)
    
    # Demand Forecasting
    elif page == "Demand Forecasting":
        forecasting_page(df)
    
    # Competitor Monitor
    elif page == "Competitor Monitor":
        competitor_page(df)
    
    # Inventory
    elif page == "Inventory":
        inventory_page(df)
    
    # SHAP Explainability
    elif page == "SHAP Explainability":
        explainability_page(df)
    
    # Real-Time Feed
    elif page == "Real-Time Feed":
        realtime_page(df)
    
    # Settings
    elif page == "Settings":
        settings_page()


def dashboard_page(df):
    """Main dashboard page"""
    st.title("💰 Dynamic Pricing Engine - Control Tower")
    st.markdown("---")
    
    # KPI Metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        avg_revenue = df['revenue'].mean()
        st.metric(
            label="📈 Avg Daily Revenue",
            value=f"${avg_revenue:,.0f}",
            delta=f"{np.random.uniform(-5, 15):.1f}%"
        )
    
    with col2:
        avg_elasticity = df['price_elasticity'].mean()
        st.metric(
            label="📊 Avg Price Elasticity",
            value=f"{avg_elasticity:.2f}",
            delta="Elastic"
        )
    
    with col3:
        total_inventory = df['inventory'].sum()
        st.metric(
            label="📦 Total Inventory",
            value=f"{total_inventory:,} units",
            delta=f"{np.random.uniform(-3, 8):.1f}%"
        )
    
    with col4:
        revenue_lift = np.random.uniform(8, 15)
        st.metric(
            label="🚀 Revenue Lift",
            value=f"{revenue_lift:.1f}%",
            delta="This Month"
        )
    
    st.markdown("---")
    
    # Revenue Trend
    st.subheader("📈 Revenue Trend")
    fig_revenue = px.line(
        df.groupby('date')['revenue'].sum().reset_index(),
        x='date',
        y='revenue',
        title='Daily Revenue',
        markers=True
    )
    fig_revenue.update_layout(height=300, hovermode='x unified')
    st.plotly_chart(fig_revenue, use_container_width=True)
    
    # Price vs Competitor
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("💵 Current Price vs Competitor")
        latest_data = df.tail(10)
        fig_price = go.Figure()
        fig_price.add_trace(go.Bar(
            name='Current Price',
            x=latest_data['product_name'],
            y=latest_data['current_price'],
            marker_color='blue'
        ))
        fig_price.add_trace(go.Bar(
            name='Competitor Price',
            x=latest_data['product_name'],
            y=latest_data['competitor_price'],
            marker_color='red'
        ))
        fig_price.update_layout(height=300, barmode='group')
        st.plotly_chart(fig_price, use_container_width=True)
    
    with col2:
        st.subheader("📊 Demand Distribution")
        fig_demand = px.box(df, y='demand', color='product_name', title='Demand by Product')
        fig_demand.update_layout(height=300)
        st.plotly_chart(fig_demand, use_container_width=True)
    
    # Product Table
    st.subheader("📋 Recent Pricing Decisions")
    display_df = df.tail(15)[['product_name', 'current_price', 'recommended_price',
                               'inventory', 'demand', 'revenue']].copy()
    display_df['Price Change'] = (
        ((display_df['recommended_price'] - display_df['current_price']) / 
         display_df['current_price'] * 100)
    ).round(2).astype(str) + '%'
    
    st.dataframe(display_df, use_container_width=True)


def price_analytics_page(df):
    """Price analytics page"""
    st.title("💵 Price Analytics")
    st.markdown("---")
    
    col1, col2 = st.columns([3, 1])
    
    with col2:
        selected_product = st.selectbox(
            "Select Product:",
            df['product_name'].unique()
        )
    
    product_data = df[df['product_name'] == selected_product]
    
    # Price elasticity chart
    st.subheader("Price Elasticity Curve")
    fig_elasticity = px.scatter(
        product_data,
        x='current_price',
        y='demand',
        size='revenue',
        color='price_elasticity',
        title=f'Price Elasticity - {selected_product}',
        trendline='ols'
    )
    st.plotly_chart(fig_elasticity, use_container_width=True)
    
    # Price optimization
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Current Price", f"${product_data['current_price'].iloc[-1]:.2f}")
    
    with col2:
        st.metric("Recommended Price", f"${product_data['recommended_price'].iloc[-1]:.2f}")
    
    with col3:
        price_change = (
            (product_data['recommended_price'].iloc[-1] - product_data['current_price'].iloc[-1]) /
            product_data['current_price'].iloc[-1] * 100
        )
        st.metric("Recommended Change", f"{price_change:.2f}%")
    
    # Price history
    st.subheader("Price History")
    fig_history = go.Figure()
    fig_history.add_trace(go.Scatter(
        x=product_data['date'],
        y=product_data['current_price'],
        mode='lines+markers',
        name='Current Price'
    ))
    fig_history.add_trace(go.Scatter(
        x=product_data['date'],
        y=product_data['competitor_price'],
        mode='lines+markers',
        name='Competitor Price'
    ))
    fig_history.update_layout(height=300, hovermode='x unified')
    st.plotly_chart(fig_history, use_container_width=True)


def forecasting_page(df):
    """Demand forecasting page"""
    st.title("📊 Demand Forecasting")
    st.markdown("---")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        forecast_days = st.slider("Forecast Days:", 7, 90, 30)
    
    with col2:
        selected_product = st.selectbox("Select Product:", df['product_name'].unique(), key="forecast_product")
    
    with col3:
        model_type = st.selectbox("Model:", ["XGBoost", "LightGBM", "Prophet"])
    
    # Generate forecast
    st.subheader(f"{forecast_days}-Day Forecast ({model_type})")
    
    forecast_dates = pd.date_range(start=datetime.now(), periods=forecast_days, freq='D')
    forecast_values = [np.random.randint(50, 200) for _ in range(forecast_days)]
    upper_ci = [v * 1.2 for v in forecast_values]
    lower_ci = [v * 0.8 for v in forecast_values]
    
    forecast_df = pd.DataFrame({
        'date': forecast_dates,
        'forecast': forecast_values,
        'upper_ci': upper_ci,
        'lower_ci': lower_ci
    })
    
    fig_forecast = go.Figure()
    
    # Historical data
    historical_product = df[df['product_name'] == selected_product].tail(30)
    fig_forecast.add_trace(go.Scatter(
        x=historical_product['date'],
        y=historical_product['demand'],
        mode='lines+markers',
        name='Historical Demand',
        line=dict(color='blue')
    ))
    
    # Forecast line
    fig_forecast.add_trace(go.Scatter(
        x=forecast_df['date'],
        y=forecast_df['forecast'],
        mode='lines+markers',
        name='Forecast',
        line=dict(color='green', dash='dash')
    ))
    
    # Confidence interval
    fig_forecast.add_trace(go.Scatter(
        x=forecast_df['date'].tolist() + forecast_df['date'].tolist()[::-1],
        y=forecast_df['upper_ci'].tolist() + forecast_df['lower_ci'].tolist()[::-1],
        fill='toself',
        fillcolor='rgba(0, 255, 0, 0.1)',
        line=dict(color='rgba(255, 255, 255, 0)'),
        name='Confidence Interval'
    ))
    
    fig_forecast.update_layout(height=400, hovermode='x unified')
    st.plotly_chart(fig_forecast, use_container_width=True)
    
    # Model comparison
    st.subheader("Model Performance Comparison")
    comparison_df = pd.DataFrame({
        'Model': ['XGBoost', 'LightGBM', 'Prophet', 'Random Forest'],
        'MAE': [15.2, 14.8, 18.5, 19.2],
        'RMSE': [22.1, 21.5, 26.3, 27.8],
        'MAPE': [8.5, 7.9, 11.2, 12.5]
    })
    
    st.dataframe(comparison_df, use_container_width=True)


def competitor_page(df):
    """Competitor monitoring page"""
    st.title("🏆 Competitor Monitor")
    st.markdown("---")
    
    col1, col2 = st.columns([2, 1])
    
    with col2:
        num_competitors = st.number_input("Number of Competitors:", 1, 10, 3)
    
    # Competitor price comparison
    st.subheader("Competitive Positioning")
    
    latest = df.tail(10)
    
    fig_comp = go.Figure()
    fig_comp.add_trace(go.Box(
        y=latest['current_price'],
        name='Your Price',
        marker_color='blue'
    ))
    
    for i in range(num_competitors):
        comp_price = latest['competitor_price'] + np.random.normal(0, 50, len(latest))
        fig_comp.add_trace(go.Box(
            y=comp_price,
            name=f'Competitor {i+1}',
            marker_color=f'hsl({(i+1)*60}, 70%, 50%)'
        ))
    
    fig_comp.update_layout(height=400)
    st.plotly_chart(fig_comp, use_container_width=True)
    
    # Price war detection
    st.subheader("⚠️ Price War Alerts")
    
    alerts = [
        {"product": "Laptop", "competitor": "CompetitorA", "action": "Price cut by 15%", "severity": "High"},
        {"product": "Phone", "competitor": "CompetitorB", "action": "Running promotion", "severity": "Medium"},
    ]
    
    for alert in alerts:
        if alert['severity'] == 'High':
            st.error(f"**{alert['product']}**: {alert['competitor']} - {alert['action']}")
        else:
            st.warning(f"**{alert['product']}**: {alert['competitor']} - {alert['action']}")


def inventory_page(df):
    """Inventory analytics page"""
    st.title("📦 Inventory Analytics")
    st.markdown("---")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Total Inventory", f"{df['inventory'].sum():,} units")
    
    with col2:
        st.metric("Avg Turnover", f"{(df['demand'] / df['inventory'].clip(lower=1)).mean():.2f}x")
    
    with col3:
        low_stock = (df['inventory'] < df['demand']).sum()
        st.metric("Low Stock Products", low_stock)
    
    st.markdown("---")
    
    # Inventory heatmap
    st.subheader("Inventory Status by Product")
    
    pivot_data = df.groupby('product_name')[['inventory', 'demand']].mean()
    pivot_data['turnover_ratio'] = pivot_data['demand'] / pivot_data['inventory'].clip(lower=1)
    
    fig_heatmap = px.bar(
        pivot_data.reset_index(),
        x='product_name',
        y=['inventory', 'demand'],
        title='Inventory vs Demand',
        barmode='group'
    )
    st.plotly_chart(fig_heatmap, use_container_width=True)


def explainability_page(df):
    """SHAP explainability page"""
    st.title("🔍 Model Explainability (SHAP)")
    st.markdown("---")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Global Feature Importance")
        
        features = ['Price Elasticity', 'Competitor Price', 'Inventory', 'Demand', 'Margin']
        importance = [0.35, 0.25, 0.20, 0.15, 0.05]
        
        fig_importance = px.bar(
            x=importance,
            y=features,
            orientation='h',
            title='Feature Importance',
            labels={'x': 'Importance Score'}
        )
        st.plotly_chart(fig_importance, use_container_width=True)
    
    with col2:
        st.subheader("Top Pricing Factors")
        
        factors = {
            'Competitor Price': 0.35,
            'Inventory Level': 0.25,
            'Demand Trend': 0.20,
            'Price Elasticity': 0.15,
            'Margin Goal': 0.05
        }
        
        for factor, impact in factors.items():
            st.write(f"**{factor}**: {impact*100:.0f}%")


def realtime_page(df):
    """Real-time pricing feed"""
    st.title("⚡ Real-Time Price Feed")
    st.markdown("---")
    
    # Auto-refresh
    col1, col2 = st.columns([3, 1])
    with col2:
        refresh_rate = st.selectbox("Refresh Rate:", ["1s", "5s", "30s"], index=1)
    
    # Real-time updates
    st.subheader("Live Price Updates")
    
    placeholder = st.empty()
    
    for i in range(5):
        with placeholder.container():
            for idx, row in df.tail(5).iterrows():
                price_change = np.random.uniform(-2, 2)
                color = "green" if price_change >= 0 else "red"
                
                st.markdown(f"""
                <div style="padding: 10px; background-color: #f0f0f0; border-left: 4px solid {color}; margin: 5px 0;">
                    <b>{row['product_name']}</b> - ${row['current_price']:.2f} 
                    <span style="color: {color};">({price_change:+.2f}%)</span>
                </div>
                """, unsafe_allow_html=True)


def settings_page():
    """Settings page"""
    st.title("⚙️ Settings")
    st.markdown("---")
    
    st.subheader("API Configuration")
    
    col1, col2 = st.columns(2)
    
    with col1:
        api_url = st.text_input("API URL:", "http://localhost:8000")
        min_price = st.number_input("Min Price:", 10, 1000, 100)
    
    with col2:
        max_price = st.number_input("Max Price:", 1000, 100000, 10000)
        margin_target = st.slider("Target Margin %:", 10, 50, 25)
    
    st.markdown("---")
    st.subheader("Pricing Strategy")
    
    strategy = st.selectbox(
        "Pricing Strategy:",
        ["Revenue Maximization", "Profit Maximization", "Market Share", "Inventory Clearance"]
    )
    
    elasticity_factor = st.slider("Elasticity Factor:", 0.0, 2.0, 1.0)
    
    st.markdown("---")
    
    if st.button("Save Settings", key="save_settings"):
        st.success("✅ Settings saved successfully!")


if __name__ == "__main__":
    main()
