"""
Synthetic e-commerce pricing data generator
Generates realistic clickstream and pricing data for the dynamic pricing engine
"""
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Tuple, List
import random
from src.utils.logger import Logger
from src.utils.config import settings

logger = Logger.get_logger(__name__)


class SyntheticDataGenerator:
    """Generate realistic e-commerce pricing and event data"""
    
    def __init__(self, seed: int = 42):
        """Initialize generator with seed for reproducibility"""
        np.random.seed(seed)
        random.seed(seed)
        self.seed = seed
        
        # E-commerce categories and products
        self.categories = {
            'Electronics': {
                'products': ['Laptop', 'Smartphone', 'Tablet', 'Headphones', 'Smart Watch'],
                'base_price_range': (500, 2000),
                'demand_multiplier': 1.2
            },
            'Fashion': {
                'products': ['T-Shirt', 'Jeans', 'Jacket', 'Shoes', 'Dress'],
                'base_price_range': (30, 150),
                'demand_multiplier': 1.0
            },
            'Home': {
                'products': ['Sofa', 'Chair', 'Lamp', 'Rug', 'Bookshelf'],
                'base_price_range': (100, 800),
                'demand_multiplier': 0.8
            },
            'Beauty': {
                'products': ['Face Cream', 'Shampoo', 'Perfume', 'Lipstick', 'Face Mask'],
                'base_price_range': (15, 100),
                'demand_multiplier': 1.3
            },
            'Sports': {
                'products': ['Running Shoes', 'Yoga Mat', 'Dumbbell', 'Bicycle', 'Skateboard'],
                'base_price_range': (40, 500),
                'demand_multiplier': 1.1
            }
        }
        
        self.customer_segments = ['budget', 'standard', 'premium', 'vip']
        self.seasonal_factors = ['normal', 'holiday', 'festival', 'flash_sale']
        
    def generate_products_catalog(self, n_products: int = 200) -> pd.DataFrame:
        """
        Generate a product catalog
        
        Args:
            n_products: Number of products to generate
            
        Returns:
            DataFrame with product information
        """
        logger.info(f"Generating catalog for {n_products} products")
        
        products = []
        product_id = 1000
        
        for category, info in self.categories.items():
            n_per_category = n_products // len(self.categories)
            
            for _ in range(n_per_category):
                product_name = np.random.choice(info['products'])
                base_price = np.random.uniform(*info['base_price_range'])
                
                products.append({
                    'product_id': product_id,
                    'product_name': f"{product_name} #{product_id}",
                    'category': category,
                    'base_price': base_price,
                    'rating': np.random.uniform(2.0, 5.0),
                    'review_count': np.random.randint(10, 5000),
                })
                product_id += 1
        
        df = pd.DataFrame(products)
        logger.info(f"Generated {len(df)} products")
        return df
    
    def generate_pricing_data(self, n_records: int = 100000, days_back: int = 90) -> pd.DataFrame:
        """
        Generate synthetic pricing and sales data
        
        Args:
            n_records: Number of records to generate
            days_back: Number of days of historical data
            
        Returns:
            DataFrame with pricing data
        """
        logger.info(f"Generating {n_records} pricing records")
        
        products_df = self.generate_products_catalog(100)
        
        records = []
        start_date = datetime.now() - timedelta(days=days_back)
        
        for _ in range(n_records):
            product = products_df.sample(1).iloc[0]
            
            # Random timestamp
            days_offset = np.random.randint(0, days_back)
            hours_offset = np.random.randint(0, 24)
            timestamp = start_date + timedelta(days=days_offset, hours=hours_offset)
            
            # Seasonal and temporal factors
            day_of_week = timestamp.weekday()
            month = timestamp.month
            
            is_weekend = 1 if day_of_week >= 5 else 0
            is_holiday = 1 if month in [12, 1] else 0  # December-January holidays
            
            seasonal_factor = np.random.choice(self.seasonal_factors, p=[0.6, 0.2, 0.15, 0.05])
            
            # Generate pricing data
            base_price = product['base_price']
            competitor_price = base_price * np.random.uniform(0.85, 1.15)
            
            # Price adjustment based on competitor
            price_diff = competitor_price - base_price
            current_price = base_price + (price_diff * np.random.uniform(0, 0.5))
            
            # Inventory and demand dynamics
            inventory_level = np.random.randint(5, 500)
            
            # Demand influenced by price, season, and competitor price
            demand = (100 + np.random.normal(0, 20)) * self.categories[product['category']]['demand_multiplier']
            demand = demand * (1 + 0.3 * is_weekend) * (1 + 0.5 * is_holiday)
            
            if seasonal_factor == 'flash_sale':
                demand *= 2.5
                current_price *= 0.7  # 30% discount
            elif seasonal_factor == 'festival':
                demand *= 2.0
                current_price *= 0.85
            
            demand = max(5, demand)
            
            # Customer metrics
            click_events = int(demand * np.random.uniform(0.5, 2.0))
            cart_additions = int(click_events * np.random.uniform(0.05, 0.25))
            purchases = int(cart_additions * np.random.uniform(0.3, 0.8))
            
            # Revenue and margin
            revenue = purchases * current_price
            cost = base_price * 0.4  # Assume 40% COGS
            profit = (revenue - (purchases * cost))
            
            customer_segment = np.random.choice(self.customer_segments)
            discount_percentage = np.random.uniform(0, 30)
            
            # Price elasticity effect
            price_elasticity = -1.5 + np.random.normal(0, 0.3)  # Negative elasticity
            
            records.append({
                'timestamp': timestamp,
                'product_id': product['product_id'],
                'product_name': product['product_name'],
                'category': product['category'],
                'current_price': current_price,
                'competitor_price': competitor_price,
                'base_price': base_price,
                'inventory_level': inventory_level,
                'click_events': click_events,
                'cart_additions': cart_additions,
                'purchases': purchases,
                'order_history': np.random.randint(5, 100),
                'customer_segment': customer_segment,
                'seasonal_factor': seasonal_factor,
                'discount_percentage': discount_percentage,
                'product_rating': product['rating'],
                'demand': demand,
                'revenue': revenue,
                'profit': profit,
                'day_of_week': day_of_week,
                'is_weekend': is_weekend,
                'is_holiday': is_holiday,
                'price_elasticity': price_elasticity,
                'margin_percentage': (profit / revenue * 100) if revenue > 0 else 0,
            })
        
        df = pd.DataFrame(records)
        df = df.sort_values('timestamp').reset_index(drop=True)
        
        logger.info(f"Generated pricing data with shape {df.shape}")
        logger.info(f"Date range: {df['timestamp'].min()} to {df['timestamp'].max()}")
        
        return df
    
    def generate_competitor_data(self, pricing_df: pd.DataFrame) -> pd.DataFrame:
        """
        Generate competitor pricing data
        
        Args:
            pricing_df: Base pricing DataFrame
            
        Returns:
            DataFrame with competitor prices
        """
        logger.info("Generating competitor pricing data")
        
        # Sample unique products and timestamps
        competitor_records = []
        
        for product_id in pricing_df['product_id'].unique()[:50]:  # Top 50 products
            product_data = pricing_df[pricing_df['product_id'] == product_id]
            
            for timestamp in product_data['timestamp'].unique()[::10]:  # Every 10th timestamp
                competitors = []
                for i in range(3):  # 3 competitors
                    price = product_data[product_data['timestamp'] == timestamp]['competitor_price'].mean()
                    price = price * np.random.uniform(0.9, 1.1)
                    
                    competitors.append({
                        'timestamp': timestamp,
                        'product_id': product_id,
                        'competitor_id': f'COMP_{i+1}',
                        'competitor_price': price,
                    })
                
                competitor_records.extend(competitors)
        
        df = pd.DataFrame(competitor_records)
        logger.info(f"Generated {len(df)} competitor price records")
        return df
    
    def save_data(self, pricing_df: pd.DataFrame, competitor_df: pd.DataFrame = None) -> None:
        """
        Save generated data to CSV files
        
        Args:
            pricing_df: Pricing DataFrame
            competitor_df: Competitor pricing DataFrame
        """
        pricing_path = settings.DATA_DIR / "pricing_data.csv"
        pricing_df.to_csv(pricing_path, index=False)
        logger.info(f"Saved pricing data to {pricing_path}")
        
        if competitor_df is not None:
            competitor_path = settings.DATA_DIR / "competitor_data.csv"
            competitor_df.to_csv(competitor_path, index=False)
            logger.info(f"Saved competitor data to {competitor_path}")
    
    def generate_all(self, n_records: int = 100000) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Generate all data at once
        
        Args:
            n_records: Number of pricing records
            
        Returns:
            Tuple of (pricing_df, competitor_df)
        """
        logger.info("Starting synthetic data generation")
        
        pricing_df = self.generate_pricing_data(n_records=n_records)
        competitor_df = self.generate_competitor_data(pricing_df)
        
        self.save_data(pricing_df, competitor_df)
        
        logger.info("Data generation complete!")
        return pricing_df, competitor_df


if __name__ == "__main__":
    generator = SyntheticDataGenerator(seed=42)
    pricing_df, competitor_df = generator.generate_all(n_records=100000)
    
    print("\n=== Data Summary ===")
    print(f"Pricing data shape: {pricing_df.shape}")
    print(f"Competitor data shape: {competitor_df.shape}")
    print("\nPricing data sample:")
    print(pricing_df.head())
    print("\nPricing data info:")
    print(pricing_df.info())
