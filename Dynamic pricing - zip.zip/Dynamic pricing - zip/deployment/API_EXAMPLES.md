# API Usage Examples for Dynamic Pricing Engine

## Base URL
```
http://localhost:8000
```

## Health Check

### Request
```bash
curl -X GET "http://localhost:8000/health"
```

### Response
```json
{
  "status": "healthy",
  "version": "1.0.0",
  "timestamp": "2024-05-07T14:30:00Z",
  "models_loaded": true
}
```

---

## 1. Price Recommendation

### Request
```bash
curl -X POST "http://localhost:8000/predict-price" \
  -H "Content-Type: application/json" \
  -d '{
    "product": {
      "product_id": 1001,
      "product_name": "Premium Laptop",
      "base_price": 1000,
      "current_price": 950,
      "category": "Electronics",
      "rating": 4.5
    },
    "market_conditions": {
      "competitor_price": 1100,
      "inventory_level": 50,
      "demand_trend": 1.2,
      "elasticity": -1.8
    },
    "forecast": {
      "demand_forecast": 100,
      "price_elasticity": -1.8,
      "trend": "trending_up"
    }
  }'
```

### Response
```json
{
  "product_id": 1001,
  "current_price": 950.0,
  "recommended_price": 1049.5,
  "price_change_pct": 10.47,
  "competitor_price": 1100.0,
  "expected_revenue_lift_pct": 15.32,
  "profit_margin_new": 0.42,
  "stockout_risk": 0.15,
  "confidence_score": 85.5,
  "reason": "increasing demand; low price sensitivity",
  "timestamp": "2024-05-07T14:30:00Z"
}
```

---

## 2. Demand Forecast

### Request - Basic
```bash
curl -X GET "http://localhost:8000/forecast-demand?product_id=1001&days_ahead=30"
```

### Request - With Python
```python
import requests

response = requests.get(
    "http://localhost:8000/forecast-demand",
    params={
        "product_id": 1001,
        "days_ahead": 30
    }
)
forecast = response.json()
print(forecast)
```

### Response
```json
{
  "product_id": 1001,
  "forecast_days": 30,
  "demand_forecast": [100, 102, 105, 108, 110, ...],
  "confidence_intervals": {
    "upper": [120, 122, 125, 128, 130, ...],
    "lower": [80, 82, 85, 88, 90, ...]
  },
  "timestamp": "2024-05-07T14:30:00Z"
}
```

---

## 3. Inventory Update

### Request
```bash
curl -X POST "http://localhost:8000/inventory-update" \
  -H "Content-Type: application/json" \
  -d '{
    "product_id": 1001,
    "inventory_level": 75,
    "timestamp": "2024-05-07T14:30:00Z"
  }'
```

### Response
```json
{
  "status": "success",
  "message": "Inventory updated for product 1001",
  "timestamp": "2024-05-07T14:30:00Z"
}
```

---

## 4. Competitor Price Update

### Request
```bash
curl -X POST "http://localhost:8000/competitor-price-update" \
  -H "Content-Type: application/json" \
  -d '{
    "product_id": 1001,
    "competitor_id": "COMP_1",
    "competitor_price": 950.0,
    "timestamp": "2024-05-07T14:30:00Z"
  }'
```

### Response
```json
{
  "status": "success",
  "message": "Competitor price updated for product 1001",
  "price_recalculation": "queued"
}
```

---

## 5. Get Price Elasticity

### Request
```bash
curl -X GET "http://localhost:8000/elasticity/1001"
```

### Response
```json
{
  "product_id": 1001,
  "elasticity": -1.8,
  "elasticity_type": "elastic",
  "interpretation": "Demand is sensitive to price changes",
  "optimal_price_range": {
    "min": 900,
    "max": 1100
  },
  "timestamp": "2024-05-07T14:30:00Z"
}
```

---

## 6. System Metrics

### Request
```bash
curl -X GET "http://localhost:8000/metrics"
```

### Response
```json
{
  "api_version": "1.0.0",
  "timestamp": "2024-05-07T14:30:00Z",
  "uptime": "1d 5h 30m",
  "requests_processed": 15234,
  "average_latency_ms": 45.3,
  "prices_optimized_today": 1250,
  "revenue_uplift_avg_pct": 12.5,
  "health_status": "healthy"
}
```

---

## 7. Batch Optimization

### Request
```bash
curl -X POST "http://localhost:8000/batch-optimize" \
  -H "Content-Type: application/json" \
  -d '{
    "product_ids": [1001, 1002, 1003, 1004, 1005]
  }'
```

### Response
```json
{
  "total_products": 5,
  "products_optimized": 5,
  "avg_revenue_lift_pct": 12.5,
  "avg_confidence_score": 78.3,
  "timestamp": "2024-05-07T14:30:00Z"
}
```

---

## Python SDK Examples

### Installation
```bash
pip install requests python-dotenv
```

### Basic Usage
```python
import requests
import json

BASE_URL = "http://localhost:8000"

class PricingEngineClient:
    def __init__(self, base_url=BASE_URL):
        self.base_url = base_url
    
    def get_price_recommendation(self, product_info, market_conditions, forecast):
        """Get price recommendation"""
        payload = {
            "product": product_info,
            "market_conditions": market_conditions,
            "forecast": forecast
        }
        
        response = requests.post(
            f"{self.base_url}/predict-price",
            json=payload
        )
        
        return response.json()
    
    def forecast_demand(self, product_id, days_ahead=30):
        """Forecast product demand"""
        response = requests.get(
            f"{self.base_url}/forecast-demand",
            params={"product_id": product_id, "days_ahead": days_ahead}
        )
        
        return response.json()
    
    def update_inventory(self, product_id, inventory_level):
        """Update product inventory"""
        payload = {
            "product_id": product_id,
            "inventory_level": inventory_level
        }
        
        response = requests.post(
            f"{self.base_url}/inventory-update",
            json=payload
        )
        
        return response.json()
    
    def update_competitor_price(self, product_id, competitor_id, price):
        """Update competitor price"""
        payload = {
            "product_id": product_id,
            "competitor_id": competitor_id,
            "competitor_price": price
        }
        
        response = requests.post(
            f"{self.base_url}/competitor-price-update",
            json=payload
        )
        
        return response.json()
    
    def health_check(self):
        """Check API health"""
        response = requests.get(f"{self.base_url}/health")
        return response.json()

# Usage
client = PricingEngineClient()

# Get price recommendation
recommendation = client.get_price_recommendation(
    product_info={
        "product_id": 1001,
        "base_price": 1000,
        "current_price": 950,
        "category": "Electronics"
    },
    market_conditions={
        "competitor_price": 1100,
        "inventory_level": 50,
        "elasticity": -1.8
    },
    forecast={
        "demand_forecast": 100,
        "trend": "trending_up"
    }
)

print(f"Recommended Price: ${recommendation['recommended_price']:.2f}")
print(f"Revenue Lift: {recommendation['expected_revenue_lift_pct']:.1f}%")

# Forecast demand
forecast = client.forecast_demand(1001, days_ahead=30)
print(f"30-day demand forecast: {forecast['demand_forecast']}")

# Update inventory
client.update_inventory(1001, 75)

# Update competitor price
client.update_competitor_price(1001, "COMP_1", 1050)

# Check health
health = client.health_check()
print(f"API Status: {health['status']}")
```

---

## JavaScript/Node.js Example

```javascript
const axios = require('axios');

const BASE_URL = 'http://localhost:8000';

class PricingEngineClient {
  async getPriceRecommendation(productInfo, marketConditions, forecast) {
    try {
      const response = await axios.post(
        `${BASE_URL}/predict-price`,
        {
          product: productInfo,
          market_conditions: marketConditions,
          forecast: forecast
        }
      );
      return response.data;
    } catch (error) {
      console.error('Error:', error);
      throw error;
    }
  }

  async forecastDemand(productId, daysAhead = 30) {
    try {
      const response = await axios.get(
        `${BASE_URL}/forecast-demand`,
        {
          params: {
            product_id: productId,
            days_ahead: daysAhead
          }
        }
      );
      return response.data;
    } catch (error) {
      console.error('Error:', error);
      throw error;
    }
  }

  async healthCheck() {
    try {
      const response = await axios.get(`${BASE_URL}/health`);
      return response.data;
    } catch (error) {
      console.error('Error:', error);
      throw error;
    }
  }
}

// Usage
const client = new PricingEngineClient();

(async () => {
  const recommendation = await client.getPriceRecommendation(
    {
      product_id: 1001,
      base_price: 1000,
      current_price: 950,
      category: 'Electronics'
    },
    {
      competitor_price: 1100,
      inventory_level: 50,
      elasticity: -1.8
    },
    {
      demand_forecast: 100,
      trend: 'trending_up'
    }
  );

  console.log(`Recommended Price: $${recommendation.recommended_price}`);
  console.log(`Revenue Lift: ${recommendation.expected_revenue_lift_pct}%`);
})();
```

---

## Error Handling

### Error Response Format
```json
{
  "detail": "Error message describing what went wrong"
}
```

### Common HTTP Status Codes
- `200 OK` - Successful request
- `400 Bad Request` - Invalid input
- `500 Internal Server Error` - Server error

### Example Error Handling (Python)
```python
try:
    response = requests.post(
        "http://localhost:8000/predict-price",
        json=payload,
        timeout=30
    )
    response.raise_for_status()
    result = response.json()
except requests.exceptions.Timeout:
    print("Request timed out")
except requests.exceptions.HTTPError as e:
    print(f"HTTP error: {e.response.status_code}")
except requests.exceptions.RequestException as e:
    print(f"Request error: {e}")
```

---

## Rate Limiting

The API supports rate limiting to prevent abuse:
- Default: 100 requests per minute
- Configure in `src/utils/config.py`

---

## Authentication (Future)

JWT authentication will be added in v2.0:
```bash
# Get token
curl -X POST "http://localhost:8000/token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=user&password=password"

# Use token
curl -X GET "http://localhost:8000/protected-endpoint" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

---

**Last Updated: May 2024 | API Version: 1.0.0**
