# AWS Deployment Guide

## Overview

This guide walks through deploying the Dynamic Pricing Engine on AWS infrastructure using EC2, RDS, and S3.

---

## Prerequisites

1. AWS Account with appropriate IAM permissions
2. AWS CLI installed and configured
3. SSH key pair created in AWS
4. Domain name (optional but recommended)

---

## Architecture

```
┌─────────────────────────────────────┐
│      AWS Load Balancer (ALB)        │
│  API: api.pricing.example.com       │
│  Dashboard: pricing.example.com     │
└──────────────┬──────────────────────┘
               │
    ┌──────────┴──────────┐
    │                     │
┌───▼─────────┐   ┌──────▼────────┐
│  EC2 (API)  │   │ EC2 (Dashboard)
│  t3.medium  │   │ t3.small
└───┬─────────┘   └──────┬────────┘
    │                    │
    └──────────┬─────────┘
               │
    ┌──────────┴──────────────┐
    │                         │
┌───▼──────────┐    ┌────────▼─────┐
│  RDS Postgres│    │  ElastiCache │
│   db.t3.small│    │  redis.t3    │
└──────────────┘    └──────────────┘
                    
    S3 Bucket (Model Storage)
```

---

## Step 1: Setup AWS Resources

### 1.1 Create VPC and Security Groups

```bash
# Create VPC
aws ec2 create-vpc --cidr-block 10.0.0.0/16 --tag-specifications 'ResourceType=vpc,Tags=[{Key=Name,Value=pricing-vpc}]'

# Create subnet
aws ec2 create-subnet --vpc-id vpc-xxx --cidr-block 10.0.1.0/24

# Create security group
aws ec2 create-security-group \
  --group-name pricing-sg \
  --description "Security group for pricing engine" \
  --vpc-id vpc-xxx

# Allow inbound traffic
aws ec2 authorize-security-group-ingress \
  --group-id sg-xxx \
  --protocol tcp \
  --port 22 \
  --cidr 0.0.0.0/0

aws ec2 authorize-security-group-ingress \
  --group-id sg-xxx \
  --protocol tcp \
  --port 8000 \
  --cidr 0.0.0.0/0

aws ec2 authorize-security-group-ingress \
  --group-id sg-xxx \
  --protocol tcp \
  --port 8501 \
  --cidr 0.0.0.0/0
```

### 1.2 Create RDS Database

```bash
# Create RDS security group
aws ec2 create-security-group \
  --group-name pricing-db-sg \
  --description "Security group for RDS" \
  --vpc-id vpc-xxx

# Create RDS instance
aws rds create-db-instance \
  --db-instance-identifier pricing-db \
  --db-instance-class db.t3.small \
  --engine postgres \
  --master-username admin \
  --master-user-password "YourSecurePassword123!" \
  --allocated-storage 100 \
  --storage-type gp2 \
  --vpc-security-group-ids sg-xxx \
  --db-subnet-group-name pricing-subnet-group \
  --no-publicly-accessible
```

### 1.3 Create ElastiCache (Redis)

```bash
# Create ElastiCache cluster
aws elasticache create-cache-cluster \
  --cache-cluster-id pricing-redis \
  --cache-node-type cache.t3.micro \
  --engine redis \
  --num-cache-nodes 1 \
  --security-group-ids sg-xxx
```

### 1.4 Create S3 Bucket

```bash
# Create bucket
aws s3 mb s3://pricing-engine-models-$(date +%s)

# Enable versioning
aws s3api put-bucket-versioning \
  --bucket pricing-engine-models-xxx \
  --versioning-configuration Status=Enabled

# Enable encryption
aws s3api put-bucket-encryption \
  --bucket pricing-engine-models-xxx \
  --server-side-encryption-configuration '{"Rules": [{"ApplyServerSideEncryptionByDefault": {"SSEAlgorithm": "AES256"}}]}'
```

---

## Step 2: Launch EC2 Instances

### 2.1 Create EC2 Instance for API

```bash
# Launch instance
aws ec2 run-instances \
  --image-id ami-0c55b159cbfafe1f0 \
  --instance-type t3.medium \
  --key-name your-key-pair \
  --security-group-ids sg-xxx \
  --subnet-id subnet-xxx \
  --tag-specifications 'ResourceType=instance,Tags=[{Key=Name,Value=pricing-api}]' \
  --user-data file://setup-api.sh

# Get public IP
aws ec2 describe-instances --filters "Name=tag:Name,Values=pricing-api"
```

### 2.2 Create EC2 Instance for Dashboard

```bash
aws ec2 run-instances \
  --image-id ami-0c55b159cbfafe1f0 \
  --instance-type t3.small \
  --key-name your-key-pair \
  --security-group-ids sg-xxx \
  --subnet-id subnet-xxx \
  --tag-specifications 'ResourceType=instance,Tags=[{Key=Name,Value=pricing-dashboard}]' \
  --user-data file://setup-dashboard.sh
```

### 2.3 Setup Script (setup-api.sh)

```bash
#!/bin/bash
set -e

# Update system
sudo apt-get update
sudo apt-get install -y \
    docker.io \
    docker-compose \
    python3 \
    python3-pip \
    git

# Add user to docker group
sudo usermod -aG docker ubuntu

# Clone repository
cd /home/ubuntu
git clone https://github.com/yourusername/dynamic-pricing-engine.git
cd dynamic-pricing-engine

# Create environment file
cat > .env << EOF
DATABASE_URL=postgresql://admin:password@pricing-db.xxxxx.rds.amazonaws.com:5432/pricing_db
REDIS_HOST=pricing-redis.xxxxx.ng.0001.use1.cache.amazonaws.com
REDIS_PORT=6379
S3_BUCKET=pricing-engine-models-xxx
AWS_REGION=us-east-1
API_PORT=8000
LOG_LEVEL=INFO
EOF

# Build and run
docker-compose up -d api

# Configure auto-restart
sudo systemctl enable docker
```

---

## Step 3: Configure Load Balancer

```bash
# Create Application Load Balancer
aws elbv2 create-load-balancer \
  --name pricing-alb \
  --subnets subnet-xxx subnet-yyy \
  --security-groups sg-xxx \
  --scheme internet-facing \
  --type application

# Create target group for API
aws elbv2 create-target-group \
  --name pricing-api-targets \
  --protocol HTTP \
  --port 8000 \
  --vpc-id vpc-xxx

# Register API instance
aws elbv2 register-targets \
  --target-group-arn arn:aws:elasticloadbalancing:... \
  --targets Id=i-xxx Type=instance

# Create listener
aws elbv2 create-listener \
  --load-balancer-arn arn:aws:elasticloadbalancing:... \
  --protocol HTTP \
  --port 80 \
  --default-actions Type=forward,TargetGroupArn=arn:aws:elasticloadbalancing:...
```

---

## Step 4: Setup CloudWatch Monitoring

```bash
# Create CloudWatch dashboard
aws cloudwatch put-dashboard \
  --dashboard-name pricing-engine \
  --dashboard-body file://dashboard-config.json

# Create alarms
aws cloudwatch put-metric-alarm \
  --alarm-name pricing-api-high-latency \
  --alarm-description "Alert when API latency is high" \
  --metric-name Latency \
  --namespace AWS/ApplicationELB \
  --statistic Average \
  --period 60 \
  --threshold 1000 \
  --comparison-operator GreaterThanThreshold \
  --evaluation-periods 2

# Enable detailed monitoring
aws ec2 monitor-instances --instance-ids i-xxx
```

---

## Step 5: Setup SSL/TLS

```bash
# Request certificate
aws acm request-certificate \
  --domain-name pricing.example.com \
  --validation-method DNS

# Create HTTPS listener
aws elbv2 create-listener \
  --load-balancer-arn arn:aws:elasticloadbalancing:... \
  --protocol HTTPS \
  --port 443 \
  --certificates CertificateArn=arn:aws:acm:... \
  --default-actions Type=forward,TargetGroupArn=arn:aws:elasticloadbalancing:...

# Redirect HTTP to HTTPS
aws elbv2 modify-listener \
  --listener-arn arn:aws:elasticloadbalancing:... \
  --default-actions Type=redirect,RedirectConfig="{Protocol=HTTPS,Port=443,StatusCode=HTTP_301}"
```

---

## Step 6: Auto Scaling

```bash
# Create launch template
aws ec2 create-launch-template \
  --launch-template-name pricing-api-template \
  --launch-template-data '{"ImageId":"ami-xxx","InstanceType":"t3.medium"}'

# Create auto-scaling group
aws autoscaling create-auto-scaling-group \
  --auto-scaling-group-name pricing-api-asg \
  --launch-template LaunchTemplateName=pricing-api-template,Version=$Default \
  --min-size 2 \
  --max-size 10 \
  --desired-capacity 2 \
  --target-group-arns arn:aws:elasticloadbalancing:...

# Create scaling policy
aws autoscaling put-scaling-policy \
  --auto-scaling-group-name pricing-api-asg \
  --policy-name cpu-scaling \
  --policy-type TargetTrackingScaling \
  --target-tracking-configuration file://scaling-policy.json
```

---

## Step 7: Database Backup and Recovery

```bash
# Enable automated backups
aws rds modify-db-instance \
  --db-instance-identifier pricing-db \
  --backup-retention-period 30 \
  --preferred-backup-window "03:00-04:00" \
  --apply-immediately

# Create manual snapshot
aws rds create-db-snapshot \
  --db-instance-identifier pricing-db \
  --db-snapshot-identifier pricing-db-backup-$(date +%Y%m%d)

# Create read replica for disaster recovery
aws rds create-db-instance-read-replica \
  --db-instance-identifier pricing-db-read \
  --source-db-instance-identifier pricing-db
```

---

## Step 8: Monitoring and Logging

```bash
# Enable CloudWatch Logs
aws logs create-log-group --log-group-name /aws/pricing/api
aws logs create-log-group --log-group-name /aws/pricing/dashboard

# Stream application logs
docker-compose exec api tail -f /var/log/app.log | \
  aws logs put-log-events \
    --log-group-name /aws/pricing/api \
    --log-stream-name api-server
```

---

## Step 9: Cost Optimization

```bash
# Use AWS Lambda for batch processing
# Consider using Fargate instead of EC2 for dashboard
# Use CloudFront for static asset delivery
# Setup AWS Budgets for cost tracking

aws budgets create-budget \
  --account-id 123456789012 \
  --budget file://budget-config.json
```

---

## Security Best Practices

### 1. IAM Roles and Policies

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:PutObject"
      ],
      "Resource": "arn:aws:s3:::pricing-engine-models-*/*"
    },
    {
      "Effect": "Allow",
      "Action": [
        "rds:DescribeDBInstances"
      ],
      "Resource": "arn:aws:rds:*:*:db/pricing-db"
    },
    {
      "Effect": "Allow",
      "Action": [
        "elasticache:DescribeCacheClusters"
      ],
      "Resource": "*"
    }
  ]
}
```

### 2. Secrets Management

```bash
# Store secrets in AWS Secrets Manager
aws secretsmanager create-secret \
  --name pricing/db/password \
  --secret-string "YourSecurePassword123!"

# Retrieve in application
aws secretsmanager get-secret-value --secret-id pricing/db/password
```

### 3. Network Security

- Use VPC endpoints for AWS services
- Enable VPC Flow Logs
- Use Security Groups to restrict traffic
- Enable WAF for ALB protection

---

## Deployment Checklist

- [ ] VPC and subnets created
- [ ] Security groups configured
- [ ] RDS database created
- [ ] ElastiCache cluster created
- [ ] S3 bucket created
- [ ] EC2 instances launched
- [ ] Load balancer configured
- [ ] SSL/TLS certificates installed
- [ ] Auto-scaling configured
- [ ] CloudWatch monitoring enabled
- [ ] CloudWatch alarms created
- [ ] Database backup configured
- [ ] IAM roles configured
- [ ] Secrets stored in Secrets Manager
- [ ] Application deployed and tested

---

## Troubleshooting

### Issue: API Connection Timeout

```bash
# Check security group
aws ec2 describe-security-groups --group-ids sg-xxx

# Check EC2 status
aws ec2 describe-instances --instance-ids i-xxx

# SSH into instance
ssh -i key.pem ubuntu@public-ip

# Check Docker containers
docker ps -a
docker logs container-id
```

### Issue: Database Connection Failed

```bash
# Test RDS connectivity
psql -h pricing-db.xxxxx.rds.amazonaws.com -U admin -d pricing_db

# Check RDS security group
aws rds describe-db-instances --db-instance-identifier pricing-db
```

### Issue: High Costs

```bash
# Analyze spending
aws ce get-cost-and-usage \
  --time-period Start=2024-01-01,End=2024-01-31 \
  --granularity DAILY \
  --metrics "UnblendedCost"

# Identify unused resources
aws ec2 describe-instances --filters "Name=instance-state-name,Values=stopped"
```

---

## Performance Optimization

1. **Enable RDS Performance Insights**
```bash
aws rds modify-db-instance \
  --db-instance-identifier pricing-db \
  --enable-performance-insights \
  --apply-immediately
```

2. **Configure CloudFront CDN**
```bash
aws cloudfront create-distribution --distribution-config file://distribution.json
```

3. **Enable ElastiCache autofailover**
```bash
aws elasticache modify-replication-group \
  --replication-group-id pricing-redis \
  --automatic-failover-enabled
```

---

## Backup and Disaster Recovery

### Automated Backups
- Enabled on RDS (30-day retention)
- Daily snapshots stored in S3
- Cross-region replication

### Recovery Procedures
```bash
# Restore from RDS snapshot
aws rds restore-db-instance-from-db-snapshot \
  --db-instance-identifier pricing-db-restored \
  --db-snapshot-identifier pricing-db-backup-20240501

# Verify application connectivity
curl https://pricing.example.com/health
```

---

## Support and Maintenance

- Monitor AWS Personal Health Dashboard
- Subscribe to AWS Trusted Advisor
- Review AWS Well-Architected Reviews monthly
- Keep dependencies updated
- Monitor API performance metrics

---

**Last Updated: May 2024 | AWS Region: us-east-1**
